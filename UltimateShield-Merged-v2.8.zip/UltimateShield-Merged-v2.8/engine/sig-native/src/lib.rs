use aho_corasick::AhoCorasick;
use jni::objects::{JByteArray, JClass};
use jni::sys::jint;
use jni::JNIEnv;
use once_cell::sync::OnceCell;

static GLOBAL_AC: OnceCell<AhoCorasick> = OnceCell::new();

#[no_mangle]
pub extern "system" fn Java_com_ultimateshield_sig_NativeSigEngine_scanChunk(
    env: JNIEnv,
    _class: JClass,
    chunk: JByteArray,
) -> jint {
    let bytes = match env.convert_byte_array(chunk) {
        Ok(b) => b,
        Err(_) => return -1,
    };

    if let Some(ac) = GLOBAL_AC.get() {
        if let Some(mat) = ac.find(&bytes) {
            return (mat.pattern().as_u32() + 1) as jint;
        }
    }
    0 // Clean chunk
}
