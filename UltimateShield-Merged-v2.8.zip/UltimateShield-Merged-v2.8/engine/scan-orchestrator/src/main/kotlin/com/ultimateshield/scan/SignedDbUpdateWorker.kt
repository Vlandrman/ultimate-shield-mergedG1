package com.ultimateshield.scan

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.io.File
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/**
 * Verifies Ed25519 digital signatures on daily Threat-Intel delta updates before atomic swap.
 */
class SignedDbUpdateWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        // Placeholder staging files downloaded via DoH/CDN
        val stagedDb = File(applicationContext.cacheDir, "sigs.sigbin.staged")
        val stagedSig = File(applicationContext.cacheDir, "sigs.sigbin.ed25519")
        if (!stagedDb.exists() || !stagedSig.exists()) return Result.success()

        val valid = verifyEd25519(stagedDb.readBytes(), stagedSig.readBytes(), PINNED_PUBKEY_X509)
        if (!valid) {
            stagedDb.delete()
            stagedSig.delete()
            return Result.failure()
        }

        val activeDb = File(applicationContext.filesDir, "sigs_active.sigbin")
        val prevDb = File(applicationContext.filesDir, "sigs_prev.sigbin")
        if (activeDb.exists()) activeDb.copyTo(prevDb, overwrite = true)
        stagedDb.renameTo(activeDb)
        stagedSig.delete()
        return Result.success()
    }

    private fun verifyEd25519(payload: ByteArray, sigBytes: ByteArray, pubKeyX509: ByteArray): Boolean {
        if (pubKeyX509.isEmpty()) return false
        return runCatching {
            val pubKey = KeyFactory.getInstance("Ed25519").generatePublic(X509EncodedKeySpec(pubKeyX509))
            val verifier = Signature.getInstance("Ed25519")
            verifier.initVerify(pubKey)
            verifier.update(payload)
            verifier.verify(sigBytes)
        }.getOrDefault(false)
    }

    companion object {
        // Replace with production 44-byte X.509 Ed25519 public key before release
        private val PINNED_PUBKEY_X509 = byteArrayOf()
    }
}
