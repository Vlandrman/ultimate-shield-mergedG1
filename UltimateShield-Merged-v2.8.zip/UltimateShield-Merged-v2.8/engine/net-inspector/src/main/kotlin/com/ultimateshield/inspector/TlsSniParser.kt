package com.ultimateshield.inspector

/**
 * Lightweight zero-dependency TLS ClientHello SNI hostname extractor for PCAP/Network Audit.
 */
object TlsSniParser {
    fun extractSni(payload: ByteArray): String? {
        if (payload.size < 43) return null
        // TLS Record Handshake (0x16) + ClientHello (0x01)
        if (payload[0].toInt() != 0x16 || payload[5].toInt() != 0x01) return null

        var pos = 43
        if (pos >= payload.size) return null
        val sessionIdLen = payload[pos].toInt() and 0xFF
        pos += 1 + sessionIdLen
        if (pos + 2 > payload.size) return null

        val cipherSuitesLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
        pos += 2 + cipherSuitesLen
        if (pos + 1 > payload.size) return null

        val compMethodsLen = payload[pos].toInt() and 0xFF
        pos += 1 + compMethodsLen
        if (pos + 2 > payload.size) return null

        val extensionsLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
        pos += 2
        val end = (pos + extensionsLen).coerceAtMost(payload.size)

        while (pos + 4 <= end) {
            val extType = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
            val extLen = ((payload[pos + 2].toInt() and 0xFF) shl 8) or (payload[pos + 3].toInt() and 0xFF)
            pos += 4
            if (extType == 0x0000 && pos + 5 <= end) { // server_name extension
                val nameLen = ((payload[pos + 3].toInt() and 0xFF) shl 8) or (payload[pos + 4].toInt() and 0xFF)
                val nameStart = pos + 5
                if (nameStart + nameLen <= end) {
                    return String(payload, nameStart, nameLen, Charsets.US_ASCII)
                }
            }
            pos += extLen
        }
        return null
    }
}
