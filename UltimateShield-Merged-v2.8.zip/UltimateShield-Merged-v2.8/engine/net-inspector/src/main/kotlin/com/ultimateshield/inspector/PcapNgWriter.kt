package com.ultimateshield.inspector

import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Standards-compliant PCAPng binary writer (SHB + IDB + EPB) compatible with Wireshark.
 */
class PcapNgWriter(private val out: OutputStream) : AutoCloseable {

    fun writeHeader() {
        // Section Header Block (Type = 0x0A0D0D0A, Total Length = 28 bytes)
        val shb = ByteBuffer.allocate(28).order(ByteOrder.LITTLE_ENDIAN).apply {
            putInt(0x0A0D0D0A)      // Block Type
            putInt(28)              // Block Total Length
            putInt(0x1A2B3C4D)      // Byte-Order Magic
            putShort(1)             // Major Version
            putShort(0)             // Minor Version
            putLong(-1L)            // Section Length (unspecified)
            putInt(28)              // Trailing Block Total Length
        }
        out.write(shb.array())

        // Interface Description Block (Type = 0x00000001, LinkType = LINKTYPE_RAW 101, Length = 20 bytes)
        val idb = ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN).apply {
            putInt(0x00000001)      // Block Type
            putInt(20)              // Block Total Length
            putShort(101)           // LinkType: Raw IP
            putShort(0)             // Reserved
            putInt(65535)           // SnapLen
            putInt(20)              // Trailing Block Total Length
        }
        out.write(idb.array())
    }

    fun writePacket(rawIpPacket: ByteArray, timestampMicros: Long = System.currentTimeMillis() * 1000L) {
        val paddedLen = (rawIpPacket.size + 3) and 3.inv()
        val totalLen = 32 + paddedLen
        val epb = ByteBuffer.allocate(totalLen).order(ByteOrder.LITTLE_ENDIAN).apply {
            putInt(0x00000006)                          // Enhanced Packet Block
            putInt(totalLen)
            putInt(0)                                   // Interface ID 0
            putInt((timestampMicros ushr 32).toInt())   // Timestamp High
            putInt((timestampMicros and 0xFFFFFFFFL).toInt()) // Timestamp Low
            putInt(rawIpPacket.size)                    // Captured Packet Length
            putInt(rawIpPacket.size)                    // Original Packet Length
            put(rawIpPacket)
            repeat(paddedLen - rawIpPacket.size) { put(0) }
            putInt(totalLen)
        }
        out.write(epb.array())
    }

    override fun close() {
        out.flush()
        out.close()
    }
}
