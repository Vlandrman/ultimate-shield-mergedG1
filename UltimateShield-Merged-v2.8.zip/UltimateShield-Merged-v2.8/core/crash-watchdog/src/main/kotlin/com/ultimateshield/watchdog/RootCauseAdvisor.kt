package com.ultimateshield.watchdog

data class DiagnosticAdvice(
    val arabicDiagnosis: String,
    val suggestedFix: String
)

/**
 * Translates raw JVM/Native/Android exceptions and security alerts into clear Arabic
 * root-cause explanations and concrete engineering fixes inside the unified Crash Radar report.
 */
object RootCauseAdvisor {

    fun diagnose(title: String, rootCause: String, stackTrace: String): DiagnosticAdvice {
        val blob = "$title $rootCause $stackTrace".lowercase()
        return when {
            "outofmemoryerror" in blob || "oom" in blob || "lmk" in blob -> DiagnosticAdvice(
                "نفاد الذاكرة العشوائية (RAM) بسبب نموذج ML ثقيل أو تضخم مخزن حزم.",
                "فعّل ملف تعريف Low-RAM، فرّغ نماذج TFLite بعد الفحص، وتأكد من إغلاق Bitmaps/Buffers."
            )
            "unsatisfiedlinkerror" in blob || "dlopen failed" in blob -> DiagnosticAdvice(
                "فشل تحميل مكتبة أصلية (.so) لعدم تطابق معمارية ABI (arm64-v8a / armeabi-v7a).",
                "تحقق من إعدادات abiFilters ووجود libultimateshield_sig_native.so وfirestack.aar لنفس المعمارية."
            )
            "sqlite" in blob || "database is locked" in blob -> DiagnosticAdvice(
                "تعارض قراءة/كتابة متزامن في قاعدة بيانات Room/SQLite.",
                "تأكد من تفعيل JournalMode.WRITE_AHEAD_LOGGING (WAL) ونقل الاستعلامات إلى @IoDispatcher."
            )
            "sslhandshake" in blob || "user ca" in blob || "certpath" in blob -> DiagnosticAdvice(
                "فشل تحقق شهادة TLS أو وجود شهادة تجسس (MITM) على الشبكة.",
                "افحص شهادات المستخدم المثبتة وأعد تفعيل نفق DoH/WireGuard الصارم."
            )
            "transactiontoolarge" in blob -> DiagnosticAdvice(
                "تجاوز حجم البيانات الممررة عبر Android Binder حد 1 ميجابايت.",
                "استخدم CrashReportFileExporter لحفظ ومشاركة التقرير كملف بدلاً من EXTRA_TEXT."
            )
            "anr" in blob || "تجمّد" in blob -> DiagnosticAdvice(
                "عملية ثقيلة أو استعلام قرص/شبكة نُفّذ على الخيط الرئيسي (Main Thread).",
                "انقل العمل الثقيل إلى Dispatchers.IO أو @ScanDispatcher المقيّد بـ limitedParallelism(2)."
            )
            else -> DiagnosticAdvice(
                "خطأ تشغيلي مسجّل في مكدس التنفيذ.",
                "انسخ التقرير الكامل أدناه وراجع السطر الأول في StackTrace لتحديد الدالة المسببة."
            )
        }
    }
}
