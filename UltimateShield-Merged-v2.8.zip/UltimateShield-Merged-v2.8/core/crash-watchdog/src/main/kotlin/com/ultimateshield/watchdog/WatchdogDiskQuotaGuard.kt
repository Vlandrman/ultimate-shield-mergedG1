package com.ultimateshield.watchdog

import android.content.Context
import java.io.File

/**
 * Guarantees the Watchdog & Crash Radar itself never bloats device storage:
 * trims unified_crash_radar.log > 2 MB and purges crash_exports/ files older than 7 days.
 */
object WatchdogDiskQuotaGuard {
    private const val MAX_LOG_BYTES = 2L * 1024L * 1024L
    private const val RETENTION_MS = 7L * 24L * 60L * 60L * 1000L

    fun enforceQuotas(context: Context, nowMs: Long = System.currentTimeMillis()): Int {
        var cleaned = 0
        val mainLog = File(context.filesDir, "unified_crash_radar.log")
        if (mainLog.exists() && mainLog.length() > MAX_LOG_BYTES) {
            val tail = mainLog.readText().takeLast(256 * 1024)
            mainLog.writeText("[TRUNCATED OLDER ENTRIES BY QUOTA GUARD]\n$tail", Charsets.UTF_8)
            cleaned++
        }

        val exportDir = File(context.cacheDir, "crash_exports")
        exportDir.listFiles()?.forEach { f ->
            if (nowMs - f.lastModified() > RETENTION_MS && f.delete()) {
                cleaned++
            }
        }
        return cleaned
    }
}
