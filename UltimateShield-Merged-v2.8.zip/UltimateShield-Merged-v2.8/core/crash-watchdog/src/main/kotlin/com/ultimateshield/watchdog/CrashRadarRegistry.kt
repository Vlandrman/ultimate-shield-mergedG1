package com.ultimateshield.watchdog

import android.content.Context
import android.content.Intent
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList

enum class IssueCategory(val arabicTitle: String) {
    CRASH("كراش / انهيار"),
    VULNERABILITY("ثغرة أمنية"),
    ERROR("خطأ برمجي"),
    PERFORMANCE("مشكلة أداء / ذاكرة"),
    VPN_NETWORK("عطل شبكة / VPN")
}

data class WatchdogRecord(
    val id: String = UUID.randomUUID().toString().take(8).uppercase(),
    val timestampMs: Long = System.currentTimeMillis(),
    val category: IssueCategory,
    val scorePercent: Int,
    val tier: SeverityTier = SeverityTier.fromPercent(scorePercent),
    val title: String,
    val rootCause: String,
    val autoFixAttempted: Boolean,
    val autoFixResult: String,
    val threadName: String = Thread.currentThread().name,
    val stackTrace: String = "",
    val occurrences: Int = 1
)

/**
 * Central Crash Radar Registry:
 * Receives every problem, error, vulnerability, and crash from ContinuousWatchdogLogger,
 * organizes all entries into ONE unified sorted report, persists it to disk (surviving process death),
 * and immediately launches CrashRadarActivity on severe/critical issues (Tier S / SS / SSS >= 85%).
 */
object CrashRadarRegistry {

    private val records = CopyOnWriteArrayList<WatchdogRecord>()
    private val _state = MutableStateFlow<List<WatchdogRecord>>(emptyList())
    val recordsFlow: StateFlow<List<WatchdogRecord>> = _state.asStateFlow()

    @Volatile
    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun ingest(record: WatchdogRecord, forceOpenScreen: Boolean = false) {
        val normalized = record.copy(
            scorePercent = record.scorePercent.coerceIn(10, 100),
            tier = SeverityTier.fromPercent(record.scorePercent)
        )
        val existingIdx = records.indexOfFirst {
            it.title == normalized.title &&
                it.rootCause == normalized.rootCause &&
                (normalized.timestampMs - it.timestampMs) <= 60_000L
        }
        if (existingIdx >= 0) {
            val prev = records[existingIdx]
            records[existingIdx] = prev.copy(
                timestampMs = normalized.timestampMs,
                occurrences = prev.occurrences + 1,
                scorePercent = maxOf(prev.scorePercent, normalized.scorePercent)
            )
        } else {
            records.add(normalized)
        }
        // Sort strictly: highest severity first (SSS -> E), then newest timestamp first
        val sorted = records.sortedWith(
            compareByDescending<WatchdogRecord> { it.scorePercent }
                .thenByDescending { it.timestampMs }
        )
        _state.value = sorted
        persistUnifiedReport(sorted)

        val minOpen = appContext?.let { WatchdogConfig.load(it).minAutoOpenPercent } ?: 85
        if (forceOpenScreen || normalized.scorePercent >= minOpen || normalized.tier.triggersCrashScreen) {
            appContext?.let { WatchdogStatusNotification.notifyCriticalIssue(it, normalized) }
            launchCrashRadarScreen(buildUnifiedTextReport(sorted), normalized)
        }
    }

    fun getSortedRecords(): List<WatchdogRecord> = _state.value

    fun clearAll() {
        records.clear()
        _state.value = emptyList()
    }

    /**
     * Compiles EVERY recorded issue, vulnerability, auto-fix, and crash into ONE clean, ordered report
     * ready for Copy All and Share buttons.
     */
    fun buildUnifiedTextReport(items: List<WatchdogRecord> = _state.value): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val highest = items.maxByOrNull { it.scorePercent }
        val sb = StringBuilder()
        sb.appendLine("====================================================")
        sb.appendLine("   ULTIMATE SHIELD — UNIFIED CRASH & WATCHDOG LOG   ")
        sb.appendLine("====================================================")
        sb.appendLine("Generated   : ${fmt.format(Date())}")
        sb.appendLine("Device      : ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT})")
        sb.appendLine("Total Issues: ${items.size}")
        sb.appendLine("Runtime     : ${RuntimeForensicsSnapshot.captureSummary()}")
        sb.appendLine("Health KPIs : ${WatchdogMetricsTracker.buildSummaryLine(items)}")
        if (highest != null) {
            sb.appendLine("Peak Rating : [ ${highest.tier.code} ] (${highest.scorePercent}% - ${highest.tier.arabicLabel})")
        }
        sb.appendLine("----------------------------------------------------")

        items.forEachIndexed { idx, r ->
            sb.appendLine()
            sb.appendLine("#${idx + 1} | [${r.tier.code}] ${r.scorePercent}% (${r.tier.arabicLabel}) | ${r.category.arabicTitle}")
            val fp = CrashFingerprinter.fingerprint(r.title, r.stackTrace)
            sb.appendLine("ID        : ${r.id} | Fingerprint: $fp | Time: ${fmt.format(Date(r.timestampMs))} | Thread: ${r.threadName}")
            sb.appendLine("Title     : ${r.title}" + if (r.occurrences > 1) " (×${r.occurrences})" else "")
            val advice = RootCauseAdvisor.diagnose(r.title, r.rootCause, r.stackTrace)
            sb.appendLine("RootCause : ${r.rootCause}")
            sb.appendLine("Diagnosis : ${advice.arabicDiagnosis}")
            sb.appendLine("Advice    : ${advice.suggestedFix}")
            sb.appendLine("AutoFix   : ${if (r.autoFixAttempted) r.autoFixResult else "Not required / Manual review"}")
            if (r.stackTrace.isNotBlank()) {
                sb.appendLine("StackTrace:")
                sb.appendLine(r.stackTrace.trim())
            }
            sb.appendLine("----------------------------------------------------")
        }
        sb.appendLine()
        sb.appendLine("=== LAST 40 BREADCRUMBS (EVENT TRAIL) ===")
        sb.appendLine(BreadcrumbTrail.formatTrail())
        sb.appendLine()
        sb.appendLine("=== AUTO-HEAL RECOVERY LEDGER ===")
        sb.appendLine(AutoHealHistoryLedger.formatLedger())
        return sb.toString()
    }

    private fun persistUnifiedReport(sorted: List<WatchdogRecord>) {
        val ctx = appContext ?: return
        runCatching {
            val file = File(ctx.filesDir, "unified_crash_radar.log")
            val text = buildUnifiedTextReport(sorted)
            file.writeText(text, Charsets.UTF_8)
            EncryptedCrashStore.writeEncrypted(ctx, text)
            if (sorted.any { it.tier.triggersCrashScreen }) {
                CrashArchiveManager.archiveReport(ctx, text)
            }
        }
    }

    private fun launchCrashRadarScreen(fullReport: String, trigger: WatchdogRecord) {
        val ctx = appContext ?: return
        runCatching {
            val intent = Intent(ctx, CrashRadarActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(CrashRadarActivity.EXTRA_FULL_REPORT, fullReport)
                putExtra(CrashRadarActivity.EXTRA_TRIGGER_TIER, trigger.tier.code)
                putExtra(CrashRadarActivity.EXTRA_TRIGGER_SCORE, trigger.scorePercent)
                putExtra(CrashRadarActivity.EXTRA_TRIGGER_TITLE, trigger.title)
                putExtra(CrashRadarActivity.EXTRA_TRIGGER_CAUSE, trigger.rootCause)
            }
            ctx.startActivity(intent)
        }
    }
}
