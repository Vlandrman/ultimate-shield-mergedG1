package com.ultimateshield.watchdog

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration

/**
 * Proactive Pre-OOM Healer listening to Android ComponentCallbacks2 memory pressure signals.
 */
class MemoryTrimWatchdog(private val context: Context) : ComponentCallbacks2 {

    override fun onTrimMemory(level: Int) {
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
            System.gc()
            val score = if (level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE) 86 else 78 // [S] or [A]
            BreadcrumbTrail.leave("MEM", "onTrimMemory level=$level -> auto-GC triggered")
            CrashRadarRegistry.ingest(
                WatchdogRecord(
                    category = IssueCategory.PERFORMANCE,
                    scorePercent = score,
                    title = "تحذير ذاكرة حرج من النظام (TrimMemory=$level)",
                    rootCause = "نظام أندرويد يوشك على قتل العملية بسبب ضغط الذاكرة العام",
                    autoFixAttempted = true,
                    autoFixResult = "تم تفريغ الذاكرة غير الحرجة وتشغيل GC استباقياً قبل OOM"
                )
            )
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {}

    @Deprecated("Deprecated in Java")
    override fun onLowMemory() {
        onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_COMPLETE)
    }
}
