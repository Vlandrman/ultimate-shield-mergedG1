package com.ultimateshield.watchdog

import android.content.Context
import android.content.Intent
import java.io.File

/**
 * Single-Entry Public Facade for the entire :core:crash-watchdog module.
 * Allows any module in Ultimate Shield to log, leave breadcrumbs, open the live console,
 * or export a diagnostics ZIP bundle in a single line of Kotlin.
 */
object WatchdogHub {

    fun start(context: Context) = ContinuousWatchdogLogger.start(context)

    fun breadcrumb(source: String, message: String) = BreadcrumbTrail.leave(source, message)

    fun report(
        category: IssueCategory,
        scorePercent: Int,
        title: String,
        rootCause: String,
        autoFixAttempted: Boolean = false,
        autoFixResult: String = ""
    ) {
        CrashRadarRegistry.ingest(
            WatchdogRecord(
                category = category,
                scorePercent = scorePercent,
                title = title,
                rootCause = rootCause,
                autoFixAttempted = autoFixAttempted,
                autoFixResult = autoFixResult
            )
        )
    }

    fun openConsole(context: Context) {
        val intent = Intent(context, WatchdogConsoleActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun exportDiagnosticsZip(context: Context, redactPii: Boolean = true): File =
        CrashBundleZipper.buildDiagnosticsZip(context, redactPii)
}
