# Third-Party Open-Source Licenses & Attribution

Ultimate Shield Android is distributed under the **GNU General Public License v3.0 (GPL-3.0)** in compliance with its integrated copyleft components:

| Upstream Project | License | Role in Ultimate Shield |
|---|---|---|
| [ShieldApp](https://github.com/beenuar/shieldapp-android) | MIT | Base Kotlin/Compose/Hilt/Tor architecture |
| [RethinkDNS](https://github.com/celzero/rethink-app) | Apache-2.0 | DoH/DoT/DNSCrypt & firewall design reference |
| [firestack](https://github.com/celzero/firestack) | MPL-2.0 | Single-TUN Go/gVisor userspace network engine |
| [NetGuard](https://github.com/m66b/netguard) | GPL-3.0-or-later | Per-app firewall rule model & OEM survival patterns |
| [PCAPdroid](https://github.com/emanuele-f/pcapdroid) / [zdtun](https://github.com/emanuele-f/zdtun) | GPL-3.0 / LGPL-3.0 | Packet inspection & PCAPng forensic reference |
| [App Manager](https://github.com/muntashirakon/appmanager) | GPL-3.0-only | Manifest/DEX forensics & tracker audit reference |
| [LibreAV](https://github.com/projectmatris/antimalwareapp) | GPL-3.0-or-later | On-device TensorFlow Lite permission/intent classifier |
| [AvarionX](https://github.com/phsycologicalFudge/AvarionX-Android-Antivirus) | MPL-2.0 | Shizuku Guardian Mode behavioral ransomware concept |

**Explicit Exclusions (ADR-003):**
- `talsec/freeMalwareDetection-Android` closed-source freemium SDK is **excluded** to preserve strict GPL-3.0 compliance; replaced with clean-room `InstallSourceAuditor.kt`.
- `Divested-Mobile/Hypatia` (AGPL-3.0) Java scanner is replaced by a clean-room Rust `aho-corasick` engine (`:engine:sig-native`).
