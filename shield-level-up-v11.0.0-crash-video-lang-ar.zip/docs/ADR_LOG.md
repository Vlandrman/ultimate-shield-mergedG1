# Architecture Decision Records (ADRs)

- **ADR-001 (Base App):** Use ShieldApp (Kotlin/Compose/Hilt/MIT) as base; never embed Flutter runtime (port AvarionX logic cleanly to Kotlin).
- **ADR-002 (Single VpnService):** `firestack` exclusively owns Android's sole `VpnService` TUN FD; all other VPN services are stripped via `tools:node="remove"`.
- **ADR-003 (License Purity):** Zero closed-source freemium SDKs (Talsec excluded) in GPL-3.0 builds; enforced automatically in CI.
- **ADR-004 (Tor Fail-Closed):** Apps configured with `TOR_STRICT` must drop packets immediately if Tor SOCKS5 (`127.0.0.1:9050`) is unavailable.
- **ADR-005 (Supply Chain & Vault):** All Threat-Intel updates require Ed25519 verification; Quarantine uses Android Keystore AES-256-GCM inside `noBackupFilesDir`.
- **ADR-006 (Dual Flavors):** Maintain clean `play` (AAB + Play Feature Delivery) and `foss` (zero proprietary Google SDKs, reproducible APK) product flavors.
