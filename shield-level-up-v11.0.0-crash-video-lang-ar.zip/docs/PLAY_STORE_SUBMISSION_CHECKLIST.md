# Google Play Console Submission Playbook

1. **VpnService Prominent Disclosure:** Verified in `VpnProminentDisclosureDialog.kt` prior to calling `VpnService.prepare()`.
2. **Review Video (90s Unlisted YouTube):**
   - 00:00–00:20: Launch app -> Show Prominent Disclosure -> Accept -> Grant VPN consent.
   - 00:20–00:50: Open Network tab -> Block Wi-Fi for a test app -> Demonstrate blocked connection.
   - 00:50–01:30: Open Scanner & Apps tabs -> Demonstrate `QUERY_ALL_PACKAGES` audit + EICAR detection.
3. **Data Safety Form:** Declare *No data collected* and *No data shared with third parties* (100% on-device local processing).
4. **Open-Source Compliance:** Include link to public GPL-3.0 GitHub repository in Play Store listing and in-app About screen.
