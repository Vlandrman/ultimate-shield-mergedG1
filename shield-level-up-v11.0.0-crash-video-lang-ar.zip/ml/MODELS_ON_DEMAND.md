# Stripped Heavy ML Models (Move to Play Feature Delivery / On-Demand CDN)

- `ml/src/main/assets/cnn_detection.tflite` (20.82 MB)
- `ml/src/main/assets/distilbert_scam_classifier.tflite` (19.35 MB)
- `ml/src/main/assets/efficientnet_b4_deepfake.tflite` (26.98 MB)
- `ml/src/main/assets/gpt_text_detector.tflite` (19.35 MB)
- `ml/src/main/assets/roberta_phishing_detector.tflite` (31.99 MB)
- `ml/src/main/assets/xception_deepfake.tflite` (31.8 MB)
- `ml/src/main/assets/xlm_roberta_multilingual.tflite` (31.99 MB)
