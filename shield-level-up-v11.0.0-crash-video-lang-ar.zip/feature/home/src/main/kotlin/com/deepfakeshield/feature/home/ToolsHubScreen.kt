package com.deepfakeshield.feature.home

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class ToolItem(val name: String, val description: String, val icon: ImageVector, val color: Color, val route: String, val category: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsHubScreen(onNavigateToTool: (String) -> Unit = {}, onNavigateToSearch: () -> Unit = {}) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableIntStateOf(0) }
    val categories = listOf("الكل", "الخصوصية", "الأمان", "الشبكة", "المراقبة", "الطوارئ")

    val tools = remember { listOf(
        ToolItem("تدقيق الخصوصية", "تقييم شامل لخصوصية جهازك", Icons.Default.PrivacyTip, Color(0xFF4CAF50), "privacy_score", "الخصوصية"),
        ToolItem("مدقّق التطبيقات", "فحص أذونات ومتتبعات التطبيقات", Icons.Default.Apps, Color(0xFF2196F3), "app_auditor", "الخصوصية"),
        ToolItem("البصمة الرقمية", "قياس تعرّض بياناتك على الإنترنت", Icons.Default.Fingerprint, Color(0xFF9C27B0), "digital_footprint", "الخصوصية"),
        ToolItem("مراقب الحافظة", "معرفة التطبيقات التي تقرأ حافظتك", Icons.Default.ContentPaste, Color(0xFFFF5722), "clipboard_monitor", "الخصوصية"),
        ToolItem("فاحص كلمات المرور", "فحص قوة كلمة المرور والتسريبات", Icons.Default.Password, Color(0xFFE91E63), "password_checker", "الأمان"),
        ToolItem("مراقب التسريبات", "فحص تسريب بياناتك وحساباتك", Icons.Default.ShieldMoon, Color(0xFFF44336), "breach_monitor", "الأمان"),
        ToolItem("مراقب الدارك ويب", "البحث عن بياناتك المسربة", Icons.Default.DarkMode, Color(0xFF1A1A2E), "dark_web_monitor", "الأمان"),
        ToolItem("فحص أرقام الاحتيال", "التحقق من الأرقام المشبوهة", Icons.Default.Phone, Color(0xFFFF9800), "scam_number_lookup", "الأمان"),
        ToolItem("الحماية من السرقة", "تأمين هاتفك ضد السرقة", Icons.Default.PhoneLocked, Color(0xFF795548), "device_theft", "الأمان"),
        ToolItem("تحليل شبكات Wi-Fi", "تشخيص عميق لأمان الشبكة", Icons.Default.Wifi, Color(0xFF00BCD4), "wifi_scanner", "الشبكة"),
        ToolItem("مراقب الشبكة", "مراقبة حركة بيانات التطبيقات", Icons.Default.DataUsage, Color(0xFF3F51B5), "network_monitor", "الشبكة"),
        ToolItem("طوارئ SOS", "أرقام الطوارئ وزر الإغاثة الفوري", Icons.Default.Sos, Color(0xFFF44336), "emergency_sos", "الطوارئ"),
        ToolItem("التعافي من الاحتيال", "دليل خطوة بخطوة لاستعادة الأمان", Icons.Default.HealthAndSafety, Color(0xFF009688), "scam_recovery", "الطوارئ"),
        ToolItem("التقرير الأسبوعي", "ملخص أمان جهازك الأسبوعي", Icons.Default.Assessment, Color(0xFF607D8B), "weekly_report", "المراقبة"),
        ToolItem("مضاد الفيروسات", "فحص شامل للجهاز ضد البرمجيات الخبيثة", Icons.Default.Security, Color(0xFF4CAF50), "diagnostics", "الأمان"),
        ToolItem("الملاحظات المشفّرة", "حفظ ملاحظاتك الحساسة بتشفير قوي", Icons.Default.Note, Color(0xFFFFC107), "secure_notes", "الأمان"),
        ToolItem("خزنة الملفات الآمنة", "تشفير وحفظ المستندات والملفات", Icons.Default.Folder, Color(0xFF8BC34A), "secure_file_vault", "الأمان"),
        ToolItem("أخبار الأمن السيبراني", "أحدث التهديدات والتحذيرات", Icons.Default.Newspaper, Color(0xFF673AB7), "security_news_feed", "المراقبة"),
        ToolItem("الخط الزمني للجهاز", "سجل الأحداث الأمنية المفصّل", Icons.Default.Timeline, Color(0xFF455A64), "device_timeline", "المراقبة"),
        ToolItem("تحدي الأمان اليومي", "اختبر وعيك ضد هجمات الاحتيال", Icons.Default.School, Color(0xFFFF9800), "daily_challenge", "المراقبة"),
        ToolItem("الإنجازات", "متابعة مستويات الأمان المكتسبة", Icons.Default.EmojiEvents, Color(0xFFFFC107), "achievements", "المراقبة"),
        ToolItem("خريطة التهديدات", "استعراض التهديدات العالمية", Icons.Default.Map, Color(0xFF009688), "threat_map", "المراقبة"),
        ToolItem("إحصائيات الحماية", "رسوم وتحليلات أداء الحماية", Icons.Default.BarChart, Color(0xFF3F51B5), "analytics", "المراقبة"),
        ToolItem("سجل الصلاحيات", "من استخدم الكاميرا والميكروفون والموقع", Icons.Default.Timeline, Color(0xFFE91E63), "permission_timeline", "الخصوصية"),
        ToolItem("حذف البيانات من الوسطاء", "إزالة بياناتك من 14 وسيط بيانات", Icons.Default.DeleteSweep, Color(0xFFF44336), "data_broker_optout", "الخصوصية"),
        ToolItem("حماية شريحة SIM", "منع الاستيلاء على رقم هاتفك", Icons.Default.SimCard, Color(0xFFFF5722), "sim_swap_protection", "الأمان"),
        ToolItem("مزيل بيانات الصور EXIF", "فحص ومسح الموقع والبيانات الخفية", Icons.Default.RemoveRedEye, Color(0xFF00BCD4), "metadata_stripper", "الخصوصية"),
        ToolItem("بريد مؤقت", "توليد عناوين بريد لحماية بريدك الأصلي", Icons.Default.AlternateEmail, Color(0xFF673AB7), "disposable_email", "الخصوصية"),
        ToolItem("كاشف النطاقات المزيفة", "اكتشاف روابط الانتحال والتصيّد", Icons.Default.Domain, Color(0xFF1A237E), "fake_domain_monitor", "الأمان"),
        ToolItem("الإبلاغ عن احتيال", "ساعد في حماية المجتمع من المحتالين", Icons.Default.ReportProblem, Color(0xFFF44336), "community_report", "الطوارئ"),
        ToolItem("وضع خصوصية Tor", "توجيه الاتصال عبر شبكة Tor المجهولة", Icons.Default.Security, Color(0xFF7C4DFF), "tor_settings", "الخصوصية"),
        ToolItem("مشاركة درجة الأمان", "شارك مستوى حماية جهازك", Icons.Default.Share, Color(0xFF2196F3), "share_score", "المراقبة"),
        ToolItem("مراقب الهوية", "لوحة شاملة لسلامة هويتك الرقمية", Icons.Default.Person, Color(0xFF9C27B0), "identity_dashboard_v2", "الخصوصية"),
    ) }

    val filtered = remember(selectedCategory, searchQuery) {
        val byCat = if (selectedCategory == 0) tools else tools.filter { it.category == categories[selectedCategory] }
        if (searchQuery.isBlank()) byCat else byCat.filter { it.name.contains(searchQuery, true) || it.description.contains(searchQuery, true) }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("أدوات الحماية", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                OutlinedTextField(
                    value = searchQuery, onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث في الأدوات...") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = { if (searchQuery.isNotEmpty()) IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Close, null) } },
                    modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(16.dp)
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    categories.forEachIndexed { i, cat ->
                        FilterChip(selected = selectedCategory == i, onClick = { selectedCategory = i }, label = { Text(cat) })
                    }
                }
            }
            item { Text("${filtered.size} أداة متاحة", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (filtered.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SearchOff, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                            Spacer(Modifier.height(8.dp)); Text("No tools match your search", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            items(filtered, key = { it.route }) { tool ->
                Card(Modifier.fillMaxWidth().clickable { onNavigateToTool(tool.route) }.animateContentSize(), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).background(tool.color.copy(alpha = 0.1f), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(tool.icon, null, Modifier.size(22.dp), tint = tool.color)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tool.name, fontWeight = FontWeight.SemiBold)
                            Text(tool.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(8.dp)) {
                            Text(tool.category, Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                }
            }
        }
    }
}
