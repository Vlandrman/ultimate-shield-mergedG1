@file:OptIn(ExperimentalMaterial3Api::class)

package com.deepfakeshield.feature.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit = {},
    onNavigateToPrivacy: () -> Unit = {},
    onNavigateToTor: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات", fontWeight = FontWeight.Bold) },
                actions = {
                    val wdCtx = androidx.compose.ui.platform.LocalContext.current
                    TextButton(onClick = {
                        runCatching {
                            val i = android.content.Intent().setClassName(wdCtx, "com.ultimateshield.watchdog.WatchdogConsoleActivity")
                            try { wdCtx.startActivity(i) } catch (_: Exception) {}
                        }
                    }) { Text("رادار الكراش", fontWeight = FontWeight.Bold) }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Official Shield Level Up Hero Banner
            val bannerCtx = androidx.compose.ui.platform.LocalContext.current
            val bannerResId = remember(bannerCtx) {
                bannerCtx.resources.getIdentifier("shield_level_up_banner", "drawable", bannerCtx.packageName)
            }
            if (bannerResId != 0) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    androidx.compose.foundation.Image(
                        painter = androidx.compose.ui.res.painterResource(id = bannerResId),
                        contentDescription = "Shield Level Up",
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                    )
                }
            }

            // Protection section
            SettingsSection("الحماية") {
                if (uiState.isBatteryOptimized) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Filled.BatteryAlert, null, modifier = Modifier.size(28.dp), tint = MaterialTheme.colorScheme.error)
                            Column(modifier = Modifier.weight(1f)) {
                                Text("قد يوقف تحسين البطارية عمل الحماية", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text("عطّله لإبقاء المراقبة نشطة 24/7", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f))
                            }
                            Button(onClick = { viewModel.requestBatteryExemption() }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
                                Text("تعطيل")
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
                SettingsToggle("الحماية الشاملة", "المفتاح الرئيسي لتفعيل أو إيقاف الحماية", Icons.Filled.Shield, uiState.masterProtection) { viewModel.setMasterProtection(it) }
                SettingsToggle("درع الفيديو", "كشف التزييف العميق في الفيديو", Icons.Filled.VideoLibrary, uiState.videoShield) { viewModel.setVideoShield(it) }
                SettingsToggle("درع الرسائل", "فحص الرسائل والروابط المشبوهة", Icons.AutoMirrored.Filled.Message, uiState.messageShield) { viewModel.setMessageShield(it) }
                SettingsToggle("درع المكالمات", "الحماية من المكالمات الاحتيالية", Icons.Filled.Phone, uiState.callShield) { viewModel.setCallShield(it) }
                SettingsToggle("حارس الحافظة", "فحص النصوص والروابط المنسوخة", Icons.Filled.ContentPaste, uiState.clipboardScanning) { viewModel.setClipboardScanning(it) }
                SettingsToggle("العزل التلقائي للتهديدات", "نقل البرمجيات الخبيثة للحجر الصحي تلقائياً", Icons.Filled.Security, uiState.autoQuarantineOnThreat) { viewModel.setAutoQuarantineOnThreat(it) }
            }

            // Threat database - update malware hashes from open-source feeds
            SettingsSection("قاعدة التهديدات") {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("قاعدة بصمات البرمجيات الخبيثة", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                        Text("${uiState.threatDbHashCount} بصمة برمجيات خبيثة معروفة. محدّثة من مصادر مفتوحة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(
                        onClick = { viewModel.updateThreatDatabase() },
                        enabled = !uiState.threatDbUpdateInProgress
                    ) {
                        if (uiState.threatDbUpdateInProgress) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                        } else {
                            Icon(Icons.Filled.CloudDownload, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(if (uiState.threatDbUpdateInProgress) "Updating…" else "تحديث الآن")
                    }
                }
                uiState.threatDbUpdateMessage?.let { msg ->
                    LaunchedEffect(msg) {
                        kotlinx.coroutines.delay(5000)
                        viewModel.clearThreatDbMessage()
                    }
                    Text(
                        msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (msg.startsWith("✓")) Color(0xFF4CAF50) else MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            // Tor Privacy
            SettingsSection("الخصوصية والشبكة") {
                Card(Modifier.fillMaxWidth().clickable { onNavigateToTor() }, shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, null, tint = Color(0xFF7C4DFF))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("وضع خصوصية Tor", fontWeight = FontWeight.SemiBold)
                            Text("توجيه اتصال التطبيق عبر شبكة Tor", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }

            // Appearance section
            SettingsSection("المظهر") {
                SettingsChips(
                    label = "المظهر",
                    options = listOf("system" to "تلقائي", "light" to "فاتح", "dark" to "داكن", "amoled" to "AMOLED"),
                    selected = uiState.themeMode,
                    onSelect = { viewModel.setThemeMode(it) }
                )
                val langCtx = androidx.compose.ui.platform.LocalContext.current
                var currentLang by remember {
                    val tag = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                        val lm = langCtx.getSystemService(android.app.LocaleManager::class.java)
                        lm?.applicationLocales?.toLanguageTags() ?: ""
                    } else {
                        java.util.Locale.getDefault().language
                    }
                    mutableStateOf(when { tag.startsWith("ar") -> "ar"; tag.startsWith("en") -> "en"; else -> "sys" })
                }
                SettingsChips(
                    label = "اللغة / Language",
                    options = listOf("ar" to "العربية", "en" to "English", "sys" to "تلقائي"),
                    selected = currentLang,
                    onSelect = { lang ->
                        currentLang = lang
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                            runCatching {
                                val lm = langCtx.getSystemService(android.app.LocaleManager::class.java)
                                lm?.applicationLocales = if (lang == "sys") android.os.LocaleList.getEmptyLocaleList()
                                else android.os.LocaleList.forLanguageTags(lang)
                            }
                        } else {
                            val locale = if (lang == "sys") java.util.Locale.getDefault() else java.util.Locale(lang)
                            java.util.Locale.setDefault(locale)
                            val cfg = android.content.res.Configuration(langCtx.resources.configuration)
                            cfg.setLocale(locale)
                            @Suppress("DEPRECATION")
                            langCtx.resources.updateConfiguration(cfg, langCtx.resources.displayMetrics)
                            (langCtx as? android.app.Activity)?.recreate()
                        }
                    }
                )
            }

            // Auto-scan schedule
            SettingsSection("الفحص المجدول") {
                SettingsChips(
                    label = "تكرار الفحص التلقائي",
                    options = listOf("off" to "إيقاف", "daily" to "يومياً", "weekly" to "أسبوعياً"),
                    selected = if (uiState.autoDeleteHandled) "daily" else "off",
                    onSelect = { /* Wire to ScheduledScanWorker config */ }
                )
            }

            // Sensitivity section
            SettingsSection("حساسية الكشف") {
                SettingsChips(
                    label = "مستوى الحماية",
                    options = listOf("gentle" to "مرن", "balanced" to "متوازن", "strict" to "صارم"),
                    selected = uiState.protectionLevel,
                    onSelect = { viewModel.setProtectionLevel(it) }
                )
                SettingsChips(
                    label = "حساسية التنبيهات",
                    options = listOf("low" to "منخفضة", "medium" to "متوسطة", "high" to "عالية"),
                    selected = uiState.alertSensitivity,
                    onSelect = { viewModel.setAlertSensitivity(it) }
                )
            }

            // Notifications section
            SettingsSection("الإشعارات") {
                SettingsToggle("إشعارات التنبيه", "تنبيهك فور رصد أي تهديد", Icons.Filled.Notifications, uiState.notificationsEnabled) { viewModel.setNotifications(it) }
                SettingsToggle("ساعات الهدوء", "كتم الإشعارات غير الحرجة ليلاً", Icons.Filled.DoNotDisturb, uiState.quietHoursEnabled) { viewModel.setQuietHours(it) }
                if (uiState.quietHoursEnabled) {
                    // Split into two rows to prevent overflow on phone screens.
                    // A single Row with 6 FilterChips + 2 Text labels needs ~464dp
                    // but only ~316dp is available after padding on standard phones.
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 56.dp, top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("من", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        listOf(21, 22, 23).forEach { hour ->
                            FilterChip(
                                selected = uiState.quietHoursStart == hour,
                                onClick = { viewModel.setQuietHoursStart(hour) },
                                label = { Text("$hour:00", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 56.dp, top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إلى", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        listOf(6, 7, 8).forEach { hour ->
                            FilterChip(
                                selected = uiState.quietHoursEnd == hour,
                                onClick = { viewModel.setQuietHoursEnd(hour) },
                                label = { Text("$hour:00", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }

            // Data section
            SettingsSection("البيانات والتخزين") {
                SettingsToggle("حذف التنبيهات المعالجة تلقائياً", "تنظيف التنبيهات التي تمت مراجعتها تلقائياً", Icons.Filled.AutoDelete, uiState.autoDeleteHandled) { viewModel.setAutoDeleteHandled(it) }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("مدة الاحتفاظ بالبيانات", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                        Text("الاحتفاظ بالبيانات لمدة ${uiState.dataRetentionDays} يوماً", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(30, 90, 365).forEach { days ->
                            FilterChip(
                                selected = uiState.dataRetentionDays == days,
                                onClick = { viewModel.setDataRetentionDays(days) },
                                label = { Text("${days}d") }
                            )
                        }
                    }
                }
            }

            // Privacy & security
            SettingsSection("الخصوصية والأمان") {
                SettingsNavItem("مركز الخصوصية", "التحكم في بياناتك والشفافية", Icons.Filled.PrivacyTip, onNavigateToPrivacy)
                SettingsToggle("التحليلات", "المساعدة في تحسين التطبيق", Icons.Filled.Analytics, uiState.analyticsEnabled) { viewModel.setAnalyticsEnabled(it) }
                SettingsToggle("تقارير الأعطال", "إرسال بيانات أعطال مجهولة الهوية", Icons.Filled.BugReport, uiState.crashlyticsEnabled) { viewModel.setCrashlyticsEnabled(it) }
            }

            // Enterprise section (when managed or for enterprise users)
            SettingsSection("النسخ الاحتياطي والتصدير") {
                if (uiState.isManagedConfig) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.Business, null, modifier = Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
                        Column(modifier = Modifier.weight(1f)) {
                            Text("مُدار بواسطة المؤسسة", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                            Text("قد يتم ضبط بعض الإعدادات عبر مسؤول تقنية المعلومات.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { viewModel.exportAllData(com.deepfakeshield.feature.settings.ExportFormat.JSON) },
                        modifier = Modifier.weight(1f),
                        enabled = uiState.isExportAllowedByAdmin && uiState.exportStatus != ExportStatus.EXPORTING,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer)
                    ) {
                        Icon(Icons.Filled.FileDownload, null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تصدير JSON")
                    }
                    Button(
                        onClick = { viewModel.exportAllData(com.deepfakeshield.feature.settings.ExportFormat.CSV) },
                        modifier = Modifier.weight(1f),
                        enabled = uiState.isExportAllowedByAdmin && uiState.exportStatus != ExportStatus.EXPORTING,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer)
                    ) {
                        Icon(Icons.Filled.TableChart, null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تصدير CSV")
                    }
                }
                if (!uiState.isExportAllowedByAdmin) {
                    Text(
                        "Export disabled by admin policy",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            // About section
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Shield Level Up", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("الإصدار ${uiState.appVersion}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("تتم جميع الفحوصات محلياً 100% على جهازك.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 4.dp))
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp), content = content)
        }
    }
}

@Composable
private fun SettingsToggle(title: String, subtitle: String, icon: ImageVector, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(icon, null, modifier = Modifier.size(24.dp), tint = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsNavItem(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsChips(label: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, display) ->
                FilterChip(
                    selected = selected == value,
                    onClick = { onSelect(value) },
                    label = { Text(display, maxLines = 1, softWrap = false) },
                    leadingIcon = if (selected == value) { { Icon(Icons.Filled.Check, null, modifier = Modifier.size(16.dp)) } } else null
                )
            }
        }
    }
}

// ===== PRIVACY SCREEN =====

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(
    viewModel: SettingsViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مركز الخصوصية والثقة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Privacy promise
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Lock, null, modifier = Modifier.size(28.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("تعهّد الخصوصية الصارم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Text("Shield Level Up processes ALL data locally on your device. Nothing is sent to any server. Your messages, calls, and videos stay private.", style = MaterialTheme.typography.bodyMedium)
                }
            }

            // What we collect
            PrivacyInfoCard("What We Process Locally", listOf(
                "SMS messages (scanned for scam patterns, never stored raw)",
                "Video frames (analyzed for deepfake indicators, immediately discarded)",
                "Call metadata (phone number patterns, no audio recorded)",
                "Notification text (scanned in real-time, not persisted)"
            ))

            // What we DON'T collect
            PrivacyInfoCard("What We NEVER Do", listOf(
                "Send your data to any server",
                "Record your calls or conversations",
                "Store your raw messages",
                "Share data with third parties",
                "Track your location",
                "Access your contacts without permission"
            ), isPositive = false)

            // Data controls
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("التحكم بالبيانات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    SettingsToggle("Analytics", "Anonymous usage stats", Icons.Filled.Analytics, uiState.analyticsEnabled) { viewModel.setAnalyticsEnabled(it) }
                    SettingsToggle("Crash Reports", "Anonymous crash data", Icons.Filled.BugReport, uiState.crashlyticsEnabled) { viewModel.setCrashlyticsEnabled(it) }

                    HorizontalDivider()

                    Button(
                        onClick = { viewModel.exportAllData() },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = uiState.exportStatus != ExportStatus.EXPORTING && uiState.isExportAllowedByAdmin,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer)
                    ) {
                        if (uiState.exportStatus == ExportStatus.EXPORTING) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.FileDownload, null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            when (uiState.exportStatus) {
                                ExportStatus.EXPORTING -> "Exporting..."
                                ExportStatus.SUCCESS -> "Exported!"
                                ExportStatus.ERROR -> "Export Failed"
                                else -> "Export My Data (GDPR)"
                            }
                        )
                    }
                    // Export error/success feedback
                    if (uiState.exportStatus == ExportStatus.ERROR && uiState.exportError != null) {
                        Text(
                            uiState.exportError ?: "Unknown error",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            // Encryption
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.EnhancedEncryption, null, tint = MaterialTheme.colorScheme.tertiary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("التشفير", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    }
                    Text("All stored data is encrypted using AES-256-GCM with device-specific keys. Even if someone accesses your device storage, they cannot read your incident data.", style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun PrivacyInfoCard(title: String, items: List<String>, isPositive: Boolean = true) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            items.forEach { item ->
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        if (isPositive) Icons.Filled.CheckCircle else Icons.Filled.Block,
                        null,
                        modifier = Modifier.size(18.dp),
                        tint = if (isPositive) Color(0xFF4CAF50) else MaterialTheme.colorScheme.error
                    )
                    Text(item, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
