package com.ultimateshield.forensics

import android.content.Context
import android.os.Build
import android.provider.Settings
import java.security.KeyStore

data class DeviceIntegrityReport(
    val userInstalledCaCount: Int,
    val adbEnabled: Boolean,
    val hasTestKeys: Boolean
) {
    val isClean: Boolean
        get() = userInstalledCaCount == 0 && !adbEnabled && !hasTestKeys
}

/**
 * Local OS & Hardware Integrity Auditor (no root required):
 * detects rogue user MITM CA certificates, active USB debugging, and unsigned test-keys ROMs.
 */
class DeviceIntegrityAuditor(private val context: Context) {

    fun runAudit(): DeviceIntegrityReport {
        val userCaCount = runCatching {
            val ks = KeyStore.getInstance("AndroidCAStore").apply { load(null) }
            ks.aliases().toList().count { it.startsWith("user:") }
        }.getOrDefault(0)

        val adbOn = runCatching {
            Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        }.getOrDefault(false)

        val testKeys = Build.TAGS?.contains("test-keys", ignoreCase = true) == true
        return DeviceIntegrityReport(userCaCount, adbOn, testKeys)
    }
}
