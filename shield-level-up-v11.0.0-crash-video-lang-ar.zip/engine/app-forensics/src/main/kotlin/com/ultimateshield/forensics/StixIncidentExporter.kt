package com.ultimateshield.forensics

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Exports a standards-compliant STIX 2.1 JSON forensic incident bundle for SIEM / Wireshark workflows.
 */
object StixIncidentExporter {
    fun buildBundleJson(
        packageName: String,
        sha256: String,
        mlScore: Float,
        c2Domains: List<String>
    ): String {
        val indicator = JSONObject().apply {
            put("type", "indicator")
            put("spec_version", "2.1")
            put("id", "indicator--${UUID.randomUUID()}")
            put("name", "Android Threat: $packageName")
            put("pattern_type", "stix")
            put("pattern", "[file:hashes.'SHA-256' = '$sha256']")
            put("x_shield_ml_score", mlScore.toDouble())
            put("x_shield_c2_domains", JSONArray(c2Domains))
        }
        return JSONObject().apply {
            put("type", "bundle")
            put("id", "bundle--${UUID.randomUUID()}")
            put("objects", JSONArray().put(indicator))
        }.toString(2)
    }
}
