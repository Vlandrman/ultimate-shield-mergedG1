package com.ultimateshield.forensics

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class AuditedAppUi(
    val packageName: String,
    val isSideloaded: Boolean,
    val trackerCount: Int,
    val riskScore: Int
)

@Composable
fun AppsAuditScreen(
    apps: List<AuditedAppUi>,
    proMode: Boolean,
    onFreezeViaShizuku: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items = apps, key = { it.packageName }) { app ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(app.packageName, style = MaterialTheme.typography.titleSmall)
                    Text(
                        "درجة الخطر: ${app.riskScore}% · متتبعات: ${app.trackerCount}" +
                            if (app.isSideloaded) " · تثبيت خارجي" else "",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (proMode) {
                    TextButton(onClick = { onFreezeViaShizuku(app.packageName) }) {
                        Text("تجميد")
                    }
                }
            }
            HorizontalDivider()
        }
    }
}
