package com.ultimateshield.scan

import java.util.concurrent.CopyOnWriteArrayList

sealed class SecuritySignal(val uid: Int, val ts: Long = System.currentTimeMillis()) {
    class SideloadedHighRiskApp(uid: Int) : SecuritySignal(uid)
    class SuspiciousRawIpOutbound(uid: Int, val ip: String) : SecuritySignal(uid)
    class HighEntropyFileBurst(uid: Int) : SecuritySignal(uid)
    class UntrustedWifiBssidChange(val ssidHash: String) : SecuritySignal(-1)
}

enum class CorrelatedAction { NONE, ISOLATE_UID_NETWORK, FORCE_STOP_AND_ISOLATE, VPN_LOCKDOWN }

/**
 * Local Mini-SIEM (V8): correlates cross-engine signals inside a 60-second sliding window.
 */
class SecurityCorrelationEngine(private val windowMs: Long = 60_000L) {

    private val recentSignals = CopyOnWriteArrayList<SecuritySignal>()

    fun ingest(signal: SecuritySignal): CorrelatedAction {
        val now = signal.ts
        recentSignals.add(signal)
        recentSignals.removeAll { now - it.ts > windowMs }

        if (signal is SecuritySignal.UntrustedWifiBssidChange) {
            return CorrelatedAction.VPN_LOCKDOWN
        }

        val uidSignals = recentSignals.filter { it.uid == signal.uid }
        val hasEntropyBurst = uidSignals.any { it is SecuritySignal.HighEntropyFileBurst }
        val hasRawIp = uidSignals.any { it is SecuritySignal.SuspiciousRawIpOutbound }
        val hasSideloadRisk = uidSignals.any { it is SecuritySignal.SideloadedHighRiskApp }

        return when {
            // Rule C2: Ransomware Burst + C2 Exfiltration
            hasEntropyBurst && hasRawIp -> CorrelatedAction.FORCE_STOP_AND_ISOLATE
            // Rule C1: Silent Spyware C2
            hasSideloadRisk && hasRawIp -> CorrelatedAction.ISOLATE_UID_NETWORK
            else -> CorrelatedAction.NONE
        }
    }
}
