package com.ultimateshield.scan

import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

data class AppAuditReport(
    val packageName: String,
    val isSideloaded: Boolean,
    val installerPackage: String?,
    val highRiskPermissions: List<String>,
    val riskScore: Int
)

/**
 * Clean-room Kotlin replacement for proprietary closed-source malware SDKs (ADR-003).
 * Inspects InstallSourceInfo + high-risk banking/spyware permissions with zero proprietary SDKs.
 */
class InstallSourceAuditor(private val pm: PackageManager) {

    private val trustedStores = setOf(
        "com.android.vending",
        "org.fdroid.fdroid",
        "com.sec.android.app.samsungapps"
    )

    private val criticalPerms = setOf(
        "android.permission.BIND_ACCESSIBILITY_SERVICE",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.REQUEST_INSTALL_PACKAGES",
        "android.permission.READ_SMS",
        "android.permission.RECEIVE_SMS",
        "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"
    )

    fun audit(packageName: String): AppAuditReport {
        val installer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching { pm.getInstallSourceInfo(packageName).installingPackageName }.getOrNull()
        } else {
            @Suppress("DEPRECATION")
            runCatching { pm.getInstallerPackageName(packageName) }.getOrNull()
        }

        val isSideloaded = installer == null || installer !in trustedStores
        val pkgInfo: PackageInfo? = runCatching {
            pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
        }.getOrNull()

        val foundCritical = pkgInfo?.requestedPermissions
            ?.filter { it in criticalPerms }
            .orEmpty()

        var score = 0
        if (isSideloaded) score += 35
        score += foundCritical.size * 20

        return AppAuditReport(
            packageName = packageName,
            isSideloaded = isSideloaded,
            installerPackage = installer,
            highRiskPermissions = foundCritical,
            riskScore = score.coerceAtMost(100)
        )
    }
}
