package com.ultimateshield.scan

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/**
 * Hardware-backed AES-256-GCM Quarantine Vault (ADR-005).
 * Encrypts malicious APKs/files into noBackupFilesDir/quarantine/{uuid}.qtn and wipes originals.
 */
class QuarantineVaultManager(private val context: Context) {

    private val keyAlias = "ultimate_shield_quarantine_aes256"
    private val vaultDir: File = File(context.noBackupFilesDir, "quarantine").apply { mkdirs() }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(keyAlias, null) as? SecretKey)?.let { return it }

        val specBuilder = KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)

        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        keyGen.init(specBuilder.build())
        return keyGen.generateKey()
    }

    /** Encrypts sourceFile into the vault, deletes sourceFile, and returns the .qtn filename. */
    fun quarantineFile(sourceFile: File): String {
        val vaultName = "${UUID.randomUUID()}.qtn"
        val outFile = File(vaultDir, vaultName)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())

        outFile.outputStream().use { rawOut ->
            // Prepend 12-byte GCM IV
            rawOut.write(cipher.iv)
            CipherOutputStream(rawOut, cipher).use { encOut ->
                sourceFile.inputStream().use { input ->
                    input.copyTo(encOut, bufferSize = 64 * 1024)
                }
            }
        }
        sourceFile.delete()
        return vaultName
    }
}
