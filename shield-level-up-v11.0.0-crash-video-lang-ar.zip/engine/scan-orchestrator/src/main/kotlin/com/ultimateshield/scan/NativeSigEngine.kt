package com.ultimateshield.scan

/**
 * JNI bridge to :engine:sig-native (Rust Aho-Corasick memory-safe scanner).
 */
object NativeSigEngine {
    private var loaded = false

    fun ensureLoaded(): Boolean {
        if (loaded) return true
        return try {
            System.loadLibrary("ultimateshield_sig_native")
            loaded = true
            true
        } catch (_: UnsatisfiedLinkError) {
            false
        }
    }

    /** Returns 0 if clean, > 0 for matched signature ID, -1 on error. */
    external fun scanChunk(chunk: ByteArray): Int
}
