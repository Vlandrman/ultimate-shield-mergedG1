package com.ultimateshield.scan

import java.net.URI
import java.util.BitSet

data class UrlVerdict(val isSuspicious: Boolean, val reason: String)

/**
 * Zero-cloud on-device URL Phishing & Smishing Guard:
 * combines Punycode/Homograph detection with a compact in-memory Bloom Filter.
 */
class PhishingUrlGuard(private val bitSize: Int = 1 shl 20) {
    private val bloom = BitSet(bitSize)

    fun addBlockedDomain(domain: String) {
        val norm = domain.lowercase().trim()
        bloom.set(hash(norm, 31))
        bloom.set(hash(norm, 131))
        bloom.set(hash(norm, 257))
    }

    fun inspectUrl(rawUrl: String): UrlVerdict {
        val host = runCatching { URI(rawUrl.trim()).host?.lowercase() }.getOrNull()
            ?: return UrlVerdict(false, "Unparseable URL")

        if (host.contains("xn--")) {
            return UrlVerdict(true, "Punycode / Homograph spoof domain detected")
        }
        if (mightContain(host)) {
            return UrlVerdict(true, "Matched local phishing Bloom Filter")
        }
        if (host.count { it == '.' } >= 4 && host.contains("login")) {
            return UrlVerdict(true, "Suspicious multi-subdomain login lure")
        }
        return UrlVerdict(false, "Clean")
    }

    private fun mightContain(domain: String): Boolean =
        bloom.get(hash(domain, 31)) && bloom.get(hash(domain, 131)) && bloom.get(hash(domain, 257))

    private fun hash(s: String, seed: Int): Int {
        var h = seed
        for (ch in s) h = (h * 31 + ch.code)
        return (h and Int.MAX_VALUE) % bitSize
    }
}
