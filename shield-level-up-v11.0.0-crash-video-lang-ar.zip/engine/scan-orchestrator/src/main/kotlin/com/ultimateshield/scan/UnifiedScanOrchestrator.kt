package com.ultimateshield.scan

import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

enum class ScanVerdict { CLEAN, RISKY, MALWARE }

data class ScanCacheRecord(
    val sha256: String,
    val filePath: String,
    val lastModified: Long,
    val verdict: ScanVerdict
)

data class ScanResult(
    val filePath: String,
    val sha256: String,
    val verdict: ScanVerdict,
    val resolvedAtTier: Int,
    val detail: String
)

/**
 * 4-Tier Early-Exit Unified Scan Engine:
 * L0: SHA-256 + Fast Cache -> L1: Rust Aho-Corasick -> L2: Static Audit -> L3: Lazy TFLite AI.
 */
class UnifiedScanOrchestrator(
    private val knownBadHashes: Set<String> = emptySet(),
    private val mlClassifier: (File) -> Float = { 0f }
) {
    private val memoryCache = ConcurrentHashMap<String, ScanCacheRecord>()

    fun scanFile(file: File): ScanResult {
        val mtime = file.lastModified()
        val cached = memoryCache[file.absolutePath]
        if (cached != null && cached.lastModified == mtime) {
            return ScanResult(file.absolutePath, cached.sha256, cached.verdict, 0, "Cache hit")
        }

        val sha256 = computeSha256(file)
        if (sha256 in knownBadHashes) {
            return saveAndReturn(file, sha256, ScanVerdict.MALWARE, 0, "Known hash match")
        }

        if (NativeSigEngine.ensureLoaded()) {
            val sigId = scanFileWithRust(file)
            if (sigId > 0) {
                return saveAndReturn(file, sha256, ScanVerdict.MALWARE, 1, "Signature #$sigId")
            }
        }

        if (file.extension.equals("apk", ignoreCase = true)) {
            val score = mlClassifier(file)
            val verdict = when {
                score >= 0.75f -> ScanVerdict.MALWARE
                score >= 0.50f -> ScanVerdict.RISKY
                else -> ScanVerdict.CLEAN
            }
            return saveAndReturn(file, sha256, verdict, 3, "TFLite score=$score")
        }

        return saveAndReturn(file, sha256, ScanVerdict.CLEAN, 1, "Clean")
    }

    private fun scanFileWithRust(file: File): Int {
        val buffer = ByteArray(64 * 1024)
        file.inputStream().use { input ->
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                val slice = if (read == buffer.size) buffer else buffer.copyOf(read)
                val hit = NativeSigEngine.scanChunk(slice)
                if (hit > 0) return hit
            }
        }
        return 0
    }

    private fun saveAndReturn(file: File, sha256: String, verdict: ScanVerdict, tier: Int, detail: String): ScanResult {
        memoryCache[file.absolutePath] = ScanCacheRecord(sha256, file.absolutePath, file.lastModified(), verdict)
        return ScanResult(file.absolutePath, sha256, verdict, tier, detail)
    }

    private fun computeSha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(64 * 1024)
        file.inputStream().use { input ->
            while (true) {
                val r = input.read(buf)
                if (r <= 0) break
                md.update(buf, 0, r)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
