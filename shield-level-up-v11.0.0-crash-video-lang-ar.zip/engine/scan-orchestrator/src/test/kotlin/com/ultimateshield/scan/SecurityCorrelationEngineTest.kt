package com.ultimateshield.scan

import org.junit.Assert.assertEquals
import org.junit.Test

class SecurityCorrelationEngineTest {

    @Test
    fun correlatesRansomwareEntropyBurstWithRawIpExfiltration() {
        val engine = SecurityCorrelationEngine(windowMs = 60_000L)
        val a1 = engine.ingest(SecuritySignal.HighEntropyFileBurst(uid = 10555))
        assertEquals(CorrelatedAction.NONE, a1)

        val a2 = engine.ingest(SecuritySignal.SuspiciousRawIpOutbound(uid = 10555, ip = "198.51.100.22"))
        assertEquals(CorrelatedAction.FORCE_STOP_AND_ISOLATE, a2)
    }
}
