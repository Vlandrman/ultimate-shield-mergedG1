package com.ultimateshield.tor

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.InetSocketAddress
import java.net.Socket

enum class TorState { STOPPED, BOOTSTRAPPING, READY, DEGRADED }

/**
 * Manages local Guardian Project tor-android SOCKS5 proxy (127.0.0.1:9050)
 * without opening a second VpnService, feeding readiness directly to firestack Fail-Closed Kill-Switch.
 */
class TorLifecycleManager(
    private val socksPort: Int = 9050,
    private val onReadinessChanged: (Boolean) -> Unit = {}
) {
    private val _state = MutableStateFlow(TorState.STOPPED)
    val state: StateFlow<TorState> = _state.asStateFlow()

    fun updateState(newState: TorState) {
        _state.value = newState
        onReadinessChanged(newState == TorState.READY)
    }

    fun probeLocalSocks5(timeoutMs: Int = 500): Boolean {
        return runCatching {
            Socket().use { s ->
                s.connect(InetSocketAddress("127.0.0.1", socksPort), timeoutMs)
                true
            }
        }.getOrDefault(false)
    }
}
