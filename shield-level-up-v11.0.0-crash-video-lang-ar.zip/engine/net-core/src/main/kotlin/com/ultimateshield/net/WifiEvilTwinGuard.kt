package com.ultimateshield.net

import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Detects Wi-Fi Evil-Twin Access Points by tracking SHA-256 hashed SSID -> BSSID bindings
 * (zero plaintext SSID storage, aligned with ShieldApp privacy model).
 */
class WifiEvilTwinGuard {
    private val trustedBindings = ConcurrentHashMap<String, String>()

    /** Returns true if a trusted SSID suddenly appears from an unknown BSSID (Evil-Twin alert). */
    fun checkWifiTransition(ssid: String, bssid: String): Boolean {
        val ssidHash = sha256(ssid)
        val bssidHash = sha256(bssid)
        val known = trustedBindings.putIfAbsent(ssidHash, bssidHash)
        return known != null && known != bssidHash
    }

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
