package com.ultimateshield.net

import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

enum class EgressMode { DIRECT_DOH, WIREGUARD, TOR_STRICT }

data class AppNetworkPolicy(
    val uid: Int,
    val allowWifi: Boolean = true,
    val allowCellular: Boolean = true,
    val allowRoaming: Boolean = false,
    val blockWhenScreenOff: Boolean = false,
    val egressMode: EgressMode = EgressMode.DIRECT_DOH
)

enum class FlowDecision { ALLOW_DIRECT, BLOCK, ROUTE_TOR_SOCKS5, ROUTE_WIREGUARD }

/**
 * Single-TUN Unified VpnService (ADR-002).
 * Owns the sole Android VpnService ParcelFileDescriptor and delegates packet
 * multiplexing to firestack (Go/gVisor) while evaluating lock-free policies in < 0.2ms.
 */
class UnifiedVpnService : VpnService() {

    private var tunInterface: ParcelFileDescriptor? = null
    private val policyCache = AtomicReference<Map<Int, AppNetworkPolicy>>(emptyMap())
    private val panicAirGapEnabled = AtomicBoolean(false)
    private val torReady = AtomicBoolean(false)

    fun updatePolicies(newRules: Map<Int, AppNetworkPolicy>) {
        policyCache.set(newRules)
    }

    fun setPanicAirGap(enabled: Boolean) {
        panicAirGapEnabled.set(enabled)
    }

    fun setTorReady(ready: Boolean) {
        torReady.set(ready)
    }

    fun startUnifiedTunnel(mtu: Int = 1500): Int {
        val builder = Builder()
            .setSession("UltimateShield")
            .setMtu(mtu)
            .addAddress("10.111.222.1", 24)
            .addAddress("fd66:f83a:c650::1", 120)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .addDnsServer("10.111.222.3")
            .addDisallowedApplication(packageName) // Mandatory loop prevention

        val pfd = builder.establish() ?: return -1
        tunInterface = pfd
        // Pass pfd.detachFd() to firestack Intra.connect(...) in integration step
        return pfd.fd
    }

    /**
     * Hot-path flow policy evaluator (< 0.2ms SLA; zero SQLite I/O).
     */
    fun evaluateFlow(
        uid: Int,
        isWifi: Boolean,
        isRoaming: Boolean,
        isScreenOff: Boolean
    ): FlowDecision {
        if (panicAirGapEnabled.get()) return FlowDecision.BLOCK

        val policy = policyCache.get()[uid] ?: AppNetworkPolicy(uid)
        if (policy.blockWhenScreenOff && isScreenOff) return FlowDecision.BLOCK
        if (isWifi && !policy.allowWifi) return FlowDecision.BLOCK
        if (!isWifi && !policy.allowCellular) return FlowDecision.BLOCK
        if (isRoaming && !policy.allowRoaming) return FlowDecision.BLOCK

        return when (policy.egressMode) {
            EgressMode.TOR_STRICT -> {
                // ADR-004: Fail-Closed Kill-Switch
                if (torReady.get()) FlowDecision.ROUTE_TOR_SOCKS5 else FlowDecision.BLOCK
            }
            EgressMode.WIREGUARD -> FlowDecision.ROUTE_WIREGUARD
            EgressMode.DIRECT_DOH -> FlowDecision.ALLOW_DIRECT
        }
    }

    override fun onDestroy() {
        tunInterface?.close()
        tunInterface = null
        super.onDestroy()
    }
}
