package com.ultimateshield.net

import org.junit.Assert.assertEquals
import org.junit.Test

class UnifiedVpnPolicyTest {

    @Test
    fun torStrictEnforcesFailClosedKillSwitchWhenTorDown() {
        val svc = UnifiedVpnService()
        svc.updatePolicies(mapOf(10200 to AppNetworkPolicy(uid = 10200, egressMode = EgressMode.TOR_STRICT)))
        svc.setTorReady(false)

        val decision = svc.evaluateFlow(uid = 10200, isWifi = true, isRoaming = false, isScreenOff = false)
        assertEquals(FlowDecision.BLOCK, decision)

        svc.setTorReady(true)
        val readyDecision = svc.evaluateFlow(uid = 10200, isWifi = true, isRoaming = false, isScreenOff = false)
        assertEquals(FlowDecision.ROUTE_TOR_SOCKS5, readyDecision)
    }

    @Test
    fun panicAirGapBlocksAllTrafficImmediately() {
        val svc = UnifiedVpnService()
        svc.setPanicAirGap(true)
        assertEquals(FlowDecision.BLOCK, svc.evaluateFlow(10001, isWifi = true, isRoaming = false, isScreenOff = false))
    }
}
