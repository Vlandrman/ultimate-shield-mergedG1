package com.ultimateshield.inspector

import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.atomic.AtomicLong

data class CapturedPacketMeta(
    val uid: Int,
    val timestampMs: Long,
    val protocol: Int,
    val dstIp: String,
    val dstPort: Int,
    val sniHost: String?,
    val headerPreview: ByteArray
)

/**
 * Non-blocking bounded telemetry buffer between firestack hot-path and PCAPdroid inspector.
 * Never stalls user traffic: drops inspection frames if consumer falls behind.
 */
class PacketRingBuffer(capacity: Int = 1024) {
    private val queue = ArrayBlockingQueue<CapturedPacketMeta>(capacity)
    private val droppedFrames = AtomicLong(0L)

    fun offerNonBlocking(meta: CapturedPacketMeta): Boolean {
        val accepted = queue.offer(meta)
        if (!accepted) droppedFrames.incrementAndGet()
        return accepted
    }

    fun drainBatch(maxItems: Int = 64): List<CapturedPacketMeta> {
        val batch = ArrayList<CapturedPacketMeta>(maxItems)
        queue.drainTo(batch, maxItems)
        return batch
    }

    fun droppedCount(): Long = droppedFrames.get()
}
