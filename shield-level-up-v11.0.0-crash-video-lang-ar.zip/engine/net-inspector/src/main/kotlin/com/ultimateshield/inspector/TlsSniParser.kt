package com.ultimateshield.inspector

/**
 * Lightweight zero-dependency TLS ClientHello SNI hostname extractor for PCAP/Network Audit.
 * Hardened (v9.9.0): strict per-extension bounds, RFC 1035 hostname length (1..253), and ASCII printables validation.
 */
object TlsSniParser {
    fun extractSni(payload: ByteArray): String? {
        if (payload.size < 43) return null
        // TLS Record Handshake (0x16) + ClientHello (0x01)
        if ((payload[0].toInt() and 0xFF) != 0x16 || (payload[5].toInt() and 0xFF) != 0x01) return null

        var pos = 43
        if (pos >= payload.size) return null
        val sessionIdLen = payload[pos].toInt() and 0xFF
        pos += 1 + sessionIdLen
        if (pos + 2 > payload.size) return null

        val cipherSuitesLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
        pos += 2 + cipherSuitesLen
        if (pos + 1 > payload.size) return null

        val compMethodsLen = payload[pos].toInt() and 0xFF
        pos += 1 + compMethodsLen
        if (pos + 2 > payload.size) return null

        val extensionsLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
        pos += 2
        val end = (pos + extensionsLen).coerceAtMost(payload.size)

        while (pos + 4 <= end) {
            val extType = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos + 1].toInt() and 0xFF)
            val extLen = ((payload[pos + 2].toInt() and 0xFF) shl 8) or (payload[pos + 3].toInt() and 0xFF)
            pos += 4
            if (extLen < 0 || pos + extLen > end) break
            val extEnd = pos + extLen
            if (extType == 0x0000 && pos + 5 <= extEnd) { // server_name extension
                val nameType = payload[pos + 2].toInt() and 0xFF
                val nameLen = ((payload[pos + 3].toInt() and 0xFF) shl 8) or (payload[pos + 4].toInt() and 0xFF)
                val nameStart = pos + 5
                if (nameType == 0x00 && nameLen in 1..253 && nameStart + nameLen <= extEnd) {
                    val host = String(payload, nameStart, nameLen, Charsets.US_ASCII)
                    if (host.all { it.code in 0x21..0x7E }) return host
                }
            }
            pos = extEnd
        }
        return null
    }
}
