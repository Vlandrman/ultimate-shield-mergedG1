package com.ultimateshield.inspector

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class PcapNgWriterTest {

    @Test
    fun writesValidPcapNgSectionHeaderAndEnhancedPacketBlock() {
        val baos = ByteArrayOutputStream()
        PcapNgWriter(baos).use { writer ->
            writer.writeHeader()
            writer.writePacket(byteArrayOf(0x45, 0x00, 0x00, 0x14, 0x01))
        }
        val bytes = baos.toByteArray()
        val magic = ByteBuffer.wrap(bytes, 0, 4).order(ByteOrder.LITTLE_ENDIAN).int
        assertEquals(0x0A0D0D0A, magic)
        // 28 (SHB) + 20 (IDB) + 32 (EPB overhead) + 8 (5 bytes padded to 4-byte boundary) = 88
        assertEquals(88, bytes.size)
        assertTrue(bytes.isNotEmpty())
    }
}
