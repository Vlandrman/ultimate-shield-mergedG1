use aho_corasick::AhoCorasick;
use jni::objects::{JByteArray, JClass};
use jni::sys::jint;
use jni::JNIEnv;
use once_cell::sync::OnceCell;

static GLOBAL_AC: OnceCell<AhoCorasick> = OnceCell::new();
const MAX_CHUNK_BYTES: usize = 16 * 1024 * 1024; // 16 MB JNI chunk safety cap

pub fn scan_bytes_with_engine(ac: &AhoCorasick, bytes: &[u8]) -> i32 {
    if bytes.is_empty() {
        return 0;
    }
    if bytes.len() > MAX_CHUNK_BYTES {
        return -2;
    }
    if let Some(mat) = ac.find(bytes) {
        return (mat.pattern().as_u32() + 1) as i32;
    }
    0
}

#[no_mangle]
pub extern "system" fn Java_com_ultimateshield_sig_NativeSigEngine_scanChunk(
    env: JNIEnv,
    _class: JClass,
    chunk: JByteArray,
) -> jint {
    let bytes = match env.convert_byte_array(chunk) {
        Ok(b) => b,
        Err(_) => return -1,
    };

    if bytes.is_empty() {
        return 0;
    }
    if bytes.len() > MAX_CHUNK_BYTES {
        return -2;
    }

    if let Some(ac) = GLOBAL_AC.get() {
        return scan_bytes_with_engine(ac, &bytes);
    }
    0 // Clean chunk
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detects_known_signature_and_ignores_clean_data() {
        let patterns: &[&[u8]] = &[b"EICAR-STANDARD-ANTIVIRUS-TEST-FILE", b"MALWARE_SIG_01"];
        let ac = AhoCorasick::new(patterns).expect("valid patterns");
        assert_eq!(scan_bytes_with_engine(&ac, b"hello clean file"), 0);
        assert_eq!(scan_bytes_with_engine(&ac, b""), 0);
        assert_eq!(scan_bytes_with_engine(&ac, b"prefix EICAR-STANDARD-ANTIVIRUS-TEST-FILE suffix"), 1);
        assert_eq!(scan_bytes_with_engine(&ac, b"payload MALWARE_SIG_01 end"), 2);
    }
}
