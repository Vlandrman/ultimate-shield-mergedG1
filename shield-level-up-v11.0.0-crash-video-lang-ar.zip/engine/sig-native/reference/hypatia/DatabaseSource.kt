package us.spotco.malwarescanner

import androidx.core.content.ContextCompat.getString

const val MT_SIGNING_KEY = "5298C0C0C3E73288"

enum class DatabaseSource(
    val id: String,
    val displayName: String,
    val downloadUrl: String,
    val publicKey: String
) {
    // Default
    MT_MAIN(
        id = "mt_main",
        displayName = getString(Utils.context!!, R.string.database_switcher_primary),
        downloadUrl = "https://maintainteam.codeberg.page/HypatiaDatabases/",
        publicKey = MT_SIGNING_KEY
    ),
    // Mirror hosted on GitHub
    MT_MIRROR(
        id = "mt_mirror",
        displayName = getString(Utils.context!!, R.string.database_switcher_mirror),
        downloadUrl = "https://maintainteam.github.io/HypatiaDatabases/",
        publicKey = MT_SIGNING_KEY
    ),
    AXP_OS(
        id = "axp_os",
        displayName = getString(Utils.context!!, R.string.database_switcher_axp_os),
        downloadUrl = "https://lav.axpos.org/db/",
        publicKey = "14C17E7F99EABF3F"
    );
}
