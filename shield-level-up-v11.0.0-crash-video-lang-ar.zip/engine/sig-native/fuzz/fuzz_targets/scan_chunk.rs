#![no_main]
use aho_corasick::AhoCorasick;
use libfuzzer_sys::fuzz_target;
use once_cell::sync::Lazy;

static SAMPLE_AC: Lazy<AhoCorasick> = Lazy::new(|| {
    AhoCorasick::new(["EICAR-STANDARD-ANTIVIRUS-TEST-FILE", "DexClassLoader", "su -c"]).unwrap()
});

fuzz_target!(|data: &[u8]| {
    let _ = SAMPLE_AC.find(data);
});
