# دليل بناء الـ APK وضمان قابلية التحديث المستمر

## 1. مفتاح التوقيع الدائم (لضمان التحديث فوق النسخة السابقة بدون حذف البيانات)
تم توليد مفتاح توقيع دائم بصلاحية 25 سنة داخل المسار:
- **الملف:** `signing/ultimate-shield-release.jks`
- **Alias:** `ultimateshield`
- **Application ID الثابت:** `com.ultimateshield.android`
- **قاعدة التحديث الإلزامية:** في كل إصدار مستقبلي، احتفظ بنفس ملف `ultimate-shield-release.jks` ونفس `applicationId` وارفع قيمة `versionCode` بمقدار `+1` (مثلاً `1 -> 2 -> 3`) داخل `app/build.gradle.kts` ليقبل أندرويد التحديث المباشر فوق النسخة المثبتة دون فقدان قواعد الجدار الناري أو السجلات.

## 2. تحويل المشروع إلى APK بضغطة زر (بدون تثبيت Android Studio)
1. ارفع محتويات هذا المجلد إلى مستودع GitHub خاص (Private Repository).
2. افتح تبويب **Actions** ← اختر **Build Signed Updatable APK** ← اضغط **Run workflow**.
3. بعد 3–5 دقائق، حمّل ملف `UltimateShield-Signed-APK` الموقّع والجاهز للتثبيت مباشرةً على هاتفك.

## 3. أو البناء محلياً في Android Studio
افتح المجلد في Android Studio (JDK 17 + Android SDK 35) ثم نفّذ:
```bash
./gradlew :app:assembleRelease
```
