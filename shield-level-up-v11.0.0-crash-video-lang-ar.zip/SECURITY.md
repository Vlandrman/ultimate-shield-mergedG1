# Security Policy & Responsible Disclosure

## Reporting a Vulnerability
We treat security vulnerabilities in **Ultimate Shield Android** (especially VPN bypasses, DNS/IPv6 leaks, JNI memory-safety bugs, or Quarantine escapes) as P0 priorities.

- **Acknowledgment SLA:** Within 48 hours of report receipt.
- **Critical Patch SLA:** Within 7 days for P0/P1 issues.
- **Emergency Signature Rollback:** False-positive signature updates can be reverted globally within 15 minutes via `manifest.json` (`rollback_to`).

Please do not open public GitHub issues for undisclosed vulnerabilities. Report privately via encrypted email / GitHub Security Advisories.
