# Ultimate Shield Android — Real Merge Report (v1.0)

## 1. Base App Reconstruction
- Reconstructed `shieldapp-android-main.zip` cleanly from `_1.zip` + `_2.zip` (176.47 MB).
- Extracted **294 base files** into the unified workspace.
- Stripped **7 oversized >10 MB `.tflite` blobs** (~182 MB) for On-Demand Play Feature Delivery (documented in `ml/MODELS_ON_DEMAND.md`).
- Disabled mandatory `google-services` / `firebase-crashlytics` plugins in `app/build.gradle.kts` for Zero-Telemetry & offline builds.

## 2. Surgical Extraction from the 8 Secondary Repositories
| Source Project | Original File | Target Unified Module Path |
|---|---|---|
| LibreAV (GPL-3.0) | `antimalwareapp-development/app/src/main/assets/saved_model.tflite` | `engine/ml-libreav/src/main/assets/libreav_saved_model.tflite` |
| LibreAV (GPL-3.0) | `antimalwareapp-development/app/src/main/assets/features.json` | `engine/ml-libreav/src/main/assets/libreav_features.json` |
| LibreAV (GPL-3.0) | `antimalwareapp-development/app/src/main/java/tech/projectmatris/antimalwareapp/scanners/ApkScanner.java` | `engine/ml-libreav/reference/ApkScanner.java` |
| AppManager (GPL-3.0-only) | `AppManager-master/app/src/main/res/values/trackers.xml` | `engine/app-forensics/src/main/res/values/audit_trackers.xml` |
| AppManager (GPL-3.0-only) | `AppManager-master/app/src/main/java/io/github/muntashirakon/AppManager/compat/AppOpsManagerCompat.java` | `engine/app-forensics/reference/AppOpsManagerCompat.java` |
| AvarionX (MPL-2.0) | `AvarionX-Android-Antivirus-main/android/app/src/main/kotlin/com/colourswift/cssecurity/ShizukuBridge.kt` | `core/ipc-shizuku/reference/avarionx/ShizukuBridge.kt` |
| AvarionX (MPL-2.0) | `AvarionX-Android-Antivirus-main/android/app/src/main/kotlin/com/colourswift/cssecurity/rtp/SystemWatcher.kt` | `core/ipc-shizuku/reference/avarionx/SystemWatcher.kt` |
| AvarionX (MPL-2.0) | `AvarionX-Android-Antivirus-main/android/app/src/main/kotlin/com/colourswift/cssecurity/rtp/SystemWatcherUserService.kt` | `core/ipc-shizuku/reference/avarionx/SystemWatcherUserService.kt` |
| AvarionX (MPL-2.0) | `AvarionX-Android-Antivirus-main/android/app/src/main/kotlin/com/colourswift/cssecurity/apkanalyser/ApkAnalyserBridge.kt` | `core/ipc-shizuku/reference/avarionx/ApkAnalyserBridge.kt` |
| AvarionX (MPL-2.0) | `AvarionX-Android-Antivirus-main/android/app/src/main/kotlin/com/colourswift/cssecurity/https/CertService.kt` | `core/ipc-shizuku/reference/avarionx/CertService.kt` |
| RethinkDNS (Apache-2.0) | `rethink-app-main/app/src/main/java/com/celzero/bravedns/service/BraveVPNService.kt` | `engine/net-core/reference/rethink/BraveVPNService.kt` |
| RethinkDNS (Apache-2.0) | `rethink-app-main/app/src/main/java/com/celzero/bravedns/service/VpnController.kt` | `engine/net-core/reference/rethink/VpnController.kt` |
| NetGuard (GPL-3.0) | `NetGuard-master/app/src/main/java/eu/faircode/netguard/Rule.java` | `engine/net-core/reference/netguard/Rule.java` |
| NetGuard (GPL-3.0) | `NetGuard-master/app/src/main/java/eu/faircode/netguard/IPUtil.java` | `engine/net-core/reference/netguard/IPUtil.java` |
| PCAPdroid (GPL-3.0) | `PCAPdroid-master/app/src/main/java/com/emanuelef/remote_capture/Geolocation.java` | `engine/net-inspector/reference/pcapdroid/Geolocation.java` |
| PCAPdroid (GPL-3.0) | `PCAPdroid-master/app/src/main/java/com/emanuelef/remote_capture/MitmAddon.java` | `engine/net-inspector/reference/pcapdroid/MitmAddon.java` |
| PCAPdroid (GPL-3.0) | `PCAPdroid-master/app/src/main/java/com/emanuelef/remote_capture/model/MatchList.java` | `engine/net-inspector/reference/pcapdroid/MatchList.java` |
| PCAPdroid (GPL-3.0) | `PCAPdroid-master/app/src/test/java/com/emanuelef/remote_capture/MatchListTest.java` | `engine/net-inspector/reference/pcapdroid/MatchListTest.java` |
| Hypatia (AGPL-3.0 ref) | `Hypatia-stable/app/src/main/java/us/spotco/malwarescanner/DatabaseSource.kt` | `engine/sig-native/reference/hypatia/DatabaseSource.kt` |

## 3. Compliance Exclusion (ADR-003)
- `freeMalwareDetection-Android-master.zip` (Talsec Freemium SDK) was **intentionally excluded** to preserve 100% GPL-3.0 compliance; replaced with clean-room `engine/scan-orchestrator/.../InstallSourceAuditor.kt`.
- `AvarionX` Flutter/Dart runtime (`lib/`, `pubspec.yaml`) was **100% excluded**; only native Kotlin bridges (`ShizukuBridge.kt`, `SystemWatcher.kt`, `ApkAnalyserBridge.kt`, `CertService.kt`) were extracted.

## 4. Unified Architecture Overlay
- Integrated **40 production Kotlin/Rust/CI/Docs files** (UnifiedVpnService, Rust Aho-Corasick, PcapNgWriter, QuarantineVault, SecurityCorrelationEngine, Shizuku Entropy Detector, and JUnit tests).

## 5. Continuous Watchdog & Crash Radar System (v1.1)
- Added `:core:crash-watchdog` module (`SeverityTier.kt`, `ContinuousWatchdogLogger.kt`, `CrashRadarRegistry.kt`, `CrashRadarActivity.kt`, `SeverityTierTest.kt`).
- Exact 9-tier severity scale implemented: `[E] 10-19%`, `[F] 20-29%`, `[D] 30-39%`, `[C] 40-54%`, `[B] 55-69%`, `[A] 70-84%`, `[S] 85-91%`, `[SS] 92-96%`, `[SSS] 97-100%`.
- Registered `CrashRadarActivity` in isolated `:crash_radar` process inside `app/src/main/AndroidManifest.xml` with bottom Copy All & Share buttons.
