<p align="center">
  <img src="app/src/main/res/drawable-nodpi/shield_level_up_banner.webp" alt="Shield Level Up" width="760" />
</p>

# Shield Level Up (`com.ultimateshield.android`)

**All-in-One Open-Source Android Security, Privacy, Anti-Scam & Forensics Suite** — built with Kotlin, Jetpack Compose, Material 3, Hilt, Embedded Tor, TensorFlow Lite, Rust Aho-Corasick, and a 24/7 Self-Healing Watchdog & Crash Radar (`v10.0.0`, `versionCode = 75`).

## Core Security & Hardening Baseline (`v10.0.0`)
- **Play Protect Safe:** Zero EFP-triggering permissions (`READ_SMS`, `RECEIVE_SMS`, `BIND_ACCESSIBILITY_SERVICE`, `BIND_NOTIFICATION_LISTENER_SERVICE`) across all 14 module manifests.
- **Zero-Crash & Zero-Leak Engineering:** `0` unsafe `!!` in production `src/main`, `0` unclosed `Cursor` / `HttpURLConnection` / `InputStream` / `MediaMetadataRetriever` / Tor TCP Socket / `Process` / `CoroutineScope` leaks, `10/10` `CancellationException`-safe WorkManager workers, and 8s ANR guards on all `BroadcastReceiver`s.
- **Defense-in-Depth Security Guards:** SSRF protection (`CWE-918`) in `ShortLinkResolver`, XXE protection (`CWE-611`) in RSS parser, CSV Formula Injection (`CWE-1236`) sanitization, Path Traversal (`CWE-22`) guards in `QuarantineManager` & `MainActivity.handleSharedFile`, strict `ALLOWED_EXTERNAL_ROUTES` allowlist, least-privilege `FileProvider` (`shared_reports/` + 24h auto-purge), Android 13+ `EXTRA_IS_SENSITIVE` clipboard masking, Tor-routed + `Add-Padding: true` HIBP k-anonymity, 1-tap EXIF/GPS photo stripper, and runtime APK SHA-256 signature pinning in `AppIntegritySelfCheck`.
- **24/7 Watchdog & Crash Radar (`:core:crash-watchdog`):** Isolated `:crash_radar` process with 9-tier severity scale (`[E]` 10–19% through `[SSS]` 97–100%), atomic AES-256-GCM encrypted crash store, and 1-tap Copy All & Share.
- **Seamless In-Place Updates:** Persistent RSA-4096 keystore (`signing/ultimate-shield-release.jks`), fixed `applicationId = "com.ultimateshield.android"`, and auto-incrementing `versionCode`.

## Build via GitHub Actions
Push to `main` or trigger **Actions → Build Signed Updatable APK** to produce the signed `arm64-v8a` release APK (`ShieldLevelUp-Signed-APK`).

## License
GPL-3.0-or-later (100% open-source; zero proprietary closed-source SDKs).
