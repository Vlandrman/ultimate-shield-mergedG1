package com.ultimateshield.watchdog

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SeverityTierTest {

    @Test
    fun verifiesAllExactNineSeverityRanges() {
        assertEquals(SeverityTier.E, SeverityTier.fromPercent(10))
        assertEquals(SeverityTier.E, SeverityTier.fromPercent(19))
        assertEquals(SeverityTier.F, SeverityTier.fromPercent(20))
        assertEquals(SeverityTier.F, SeverityTier.fromPercent(29))
        assertEquals(SeverityTier.D, SeverityTier.fromPercent(30))
        assertEquals(SeverityTier.D, SeverityTier.fromPercent(39))
        assertEquals(SeverityTier.C, SeverityTier.fromPercent(40))
        assertEquals(SeverityTier.C, SeverityTier.fromPercent(54))
        assertEquals(SeverityTier.B, SeverityTier.fromPercent(55))
        assertEquals(SeverityTier.B, SeverityTier.fromPercent(69))
        assertEquals(SeverityTier.A, SeverityTier.fromPercent(70))
        assertEquals(SeverityTier.A, SeverityTier.fromPercent(84))
        assertEquals(SeverityTier.S, SeverityTier.fromPercent(85))
        assertEquals(SeverityTier.S, SeverityTier.fromPercent(91))
        assertEquals(SeverityTier.SS, SeverityTier.fromPercent(92))
        assertEquals(SeverityTier.SS, SeverityTier.fromPercent(96))
        assertEquals(SeverityTier.SSS, SeverityTier.fromPercent(97))
        assertEquals(SeverityTier.SSS, SeverityTier.fromPercent(100))

        assertFalse(SeverityTier.A.triggersCrashScreen)
        assertTrue(SeverityTier.S.triggersCrashScreen)
        assertTrue(SeverityTier.SS.triggersCrashScreen)
        assertTrue(SeverityTier.SSS.triggersCrashScreen)
    }

    @Test
    fun unifiedReportSortsHighestSeverityFirst() {
        CrashRadarRegistry.clearAll()
        CrashRadarRegistry.ingest(WatchdogRecord(category = IssueCategory.ERROR, scorePercent = 25, title = "Low F", rootCause = "minor", autoFixAttempted = false, autoFixResult = ""))
        CrashRadarRegistry.ingest(WatchdogRecord(category = IssueCategory.CRASH, scorePercent = 99, title = "Fatal SSS", rootCause = "OOM", autoFixAttempted = true, autoFixResult = "Captured"))
        CrashRadarRegistry.ingest(WatchdogRecord(category = IssueCategory.VULNERABILITY, scorePercent = 75, title = "High A", rootCause = "Perm", autoFixAttempted = false, autoFixResult = ""))

        val sorted = CrashRadarRegistry.getSortedRecords()
        assertEquals(SeverityTier.SSS, sorted[0].tier)
        assertEquals(SeverityTier.A, sorted[1].tier)
        assertEquals(SeverityTier.F, sorted[2].tier)

        val report = CrashRadarRegistry.buildUnifiedTextReport(sorted)
        assertTrue(report.contains("[ SSS ] (99%"))
        assertTrue(report.contains("Fatal SSS"))
    }
}
