package com.ultimateshield.watchdog

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WatchdogV20Test {

    @Test
    fun verifiesPeakRatingIsSssAt98Percent() {
        val tier = SeverityTier.fromPercent(98)
        assertEquals(SeverityTier.SSS, tier)
        assertTrue(tier.triggersCrashScreen)
    }
}
