package com.ultimateshield.watchdog

import org.junit.Assert.assertTrue
import org.junit.Test

class WatchdogV19Test {

    @Test
    fun metricsTrackerFormatsAutoHealRateAndTierHistogram() {
        val sample = listOf(
            WatchdogRecord(category = IssueCategory.CRASH, scorePercent = 98, title = "C1", rootCause = "r1", autoFixAttempted = true, autoFixResult = "ok"),
            WatchdogRecord(category = IssueCategory.ERROR, scorePercent = 45, title = "E1", rootCause = "r2", autoFixAttempted = false, autoFixResult = "manual")
        )
        val line = WatchdogMetricsTracker.buildSummaryLine(sample)
        assertTrue(line.contains("Auto-Heal Rate: 50% (1/2)"))
        assertTrue(line.contains("SSS:1"))
        assertTrue(line.contains("C:1"))
    }
}
