package com.ultimateshield.watchdog

import org.junit.Assert.assertTrue
import org.junit.Test

class WatchdogV21Test {

    @Test
    fun githubFormatterProducesValidCollapsibleMarkdown() {
        val sample = listOf(
            WatchdogRecord(
                category = IssueCategory.CRASH,
                scorePercent = 96,
                title = "NullPointerException",
                rootCause = "Null tunnel ref at 10.0.0.1",
                autoFixAttempted = true,
                autoFixResult = "Captured",
                stackTrace = "at com.ultimateshield.net.UnifiedVpnService.flow(UnifiedVpnService.kt:55)"
            )
        )
        val md = GitHubIssueFormatter.formatMarkdown(sample, redactPii = true)
        assertTrue(md.contains("## Ultimate Shield Crash Radar Report"))
        assertTrue(md.contains("[SS]"))
        assertTrue(md.contains("[REDACTED_IP]"))
        assertTrue(md.contains("<details><summary>StackTrace</summary>"))
    }
}
