package com.ultimateshield.watchdog

import org.junit.Assert.assertTrue
import org.junit.Test

class WatchdogV24Test {

    @Test
    fun autoHealLedgerTracksSuccessfulAndFailedRepairs() {
        AutoHealHistoryLedger.clear()
        AutoHealHistoryLedger.record("VPN", "Restarted UnifiedVpnService", true)
        AutoHealHistoryLedger.record("FD", "GC freed 120 descriptors", true)
        val out = AutoHealHistoryLedger.formatLedger()
        assertTrue(out.contains("[OK] (VPN)"))
        assertTrue(out.contains("[OK] (FD)"))
    }
}
