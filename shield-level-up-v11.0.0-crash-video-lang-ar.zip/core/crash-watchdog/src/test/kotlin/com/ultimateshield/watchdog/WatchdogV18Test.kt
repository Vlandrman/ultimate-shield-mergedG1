package com.ultimateshield.watchdog

import org.junit.Assert.assertFalse
import org.junit.Test

class WatchdogV18Test {

    @Test
    fun deadlockWatchdogReportsCleanWhenNoThreadsBlocked() {
        val outcome = DeadlockWatchdog.inspectThreads()
        assertFalse(outcome.issueDetected)
    }
}
