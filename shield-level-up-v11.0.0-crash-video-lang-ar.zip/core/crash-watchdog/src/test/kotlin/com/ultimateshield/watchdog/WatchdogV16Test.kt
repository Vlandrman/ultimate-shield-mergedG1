package com.ultimateshield.watchdog

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class WatchdogV16Test {

    @Test
    fun crashFingerprinterProducesStableDeterministicHashes() {
        val trace = """
            java.lang.NullPointerException: null object
                at com.ultimateshield.net.UnifiedVpnService.evaluateFlow(UnifiedVpnService.kt:64)
                at com.ultimateshield.net.UnifiedVpnService.startUnifiedTunnel(UnifiedVpnService.kt:42)
                at com.ultimateshield.app.MainActivity.onCreate(MainActivity.kt:30)
        """.trimIndent()
        val fp1 = CrashFingerprinter.fingerprint("NPE", trace)
        val fp2 = CrashFingerprinter.fingerprint("NPE", trace)
        val fp3 = CrashFingerprinter.fingerprint("OOM", trace)

        assertEquals(12, fp1.length)
        assertEquals(fp1, fp2)
        assertNotEquals(fp1, fp3)
    }
}
