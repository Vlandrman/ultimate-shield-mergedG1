package com.ultimateshield.watchdog

import org.junit.Assert.assertEquals
import org.junit.Test

class WatchdogV25Test {

    @Test
    fun verifiesBoundaryValuesForEveryTierFromEtoSss() {
        val expected = listOf(
            10 to "E", 19 to "E",
            20 to "F", 29 to "F",
            30 to "D", 39 to "D",
            40 to "C", 54 to "C",
            55 to "B", 69 to "B",
            70 to "A", 84 to "A",
            85 to "S", 91 to "S",
            92 to "SS", 96 to "SS",
            97 to "SSS", 100 to "SSS"
        )
        expected.forEach { (pct, code) ->
            assertEquals("Failed at $pct%", code, SeverityTier.fromPercent(pct).code)
        }
    }
}
