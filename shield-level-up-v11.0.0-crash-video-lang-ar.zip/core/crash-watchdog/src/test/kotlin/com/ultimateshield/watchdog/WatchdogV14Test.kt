package com.ultimateshield.watchdog

import org.junit.Assert.assertTrue
import org.junit.Test

class WatchdogV14Test {

    @Test
    fun advisorDiagnosesOomAndSqliteAccurately() {
        val oom = RootCauseAdvisor.diagnose("Fatal", "OutOfMemoryError", "")
        assertTrue(oom.arabicDiagnosis.contains("الذاكرة"))

        val sql = RootCauseAdvisor.diagnose("DB Error", "SQLiteDatabaseLockedException", "")
        assertTrue(sql.suggestedFix.contains("WAL"))
    }

    @Test
    fun sanitizerRedactsIpv4AndEmailsWhenEnabled() {
        val raw = "Connected to 192.168.1.45 by user@example.com"
        val clean = LogSanitizer.sanitizeForExternalShare(raw, redactNetworkPii = true)
        assertTrue(clean.contains("[REDACTED_IP]"))
        assertTrue(clean.contains("[REDACTED_EMAIL]"))
    }
}
