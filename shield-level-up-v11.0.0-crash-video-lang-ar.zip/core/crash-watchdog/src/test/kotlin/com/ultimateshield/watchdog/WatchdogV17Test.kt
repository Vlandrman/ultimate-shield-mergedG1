package com.ultimateshield.watchdog

import org.junit.Assert.assertTrue
import org.junit.Test

class WatchdogV17Test {

    @Test
    fun breadcrumbTrailRetainsMostRecentFortyEvents() {
        BreadcrumbTrail.clear()
        repeat(55) { i ->
            BreadcrumbTrail.leave("TEST", "Event #$i")
        }
        val formatted = BreadcrumbTrail.formatTrail()
        assertTrue(formatted.contains("Event #54"))
        assertTrue(!formatted.contains("Event #0\n"))
    }
}
