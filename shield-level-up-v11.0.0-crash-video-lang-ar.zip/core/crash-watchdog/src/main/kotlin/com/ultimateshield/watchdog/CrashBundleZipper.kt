package com.ultimateshield.watchdog

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Packages the unified .txt report, .json report, and up to 5 recent session archives
 * into ONE clean shareable ZIP bundle for support or GitHub issue attachment.
 */
object CrashBundleZipper {

    fun buildDiagnosticsZip(context: Context, redactPii: Boolean = true): File {
        val dir = File(context.cacheDir, "crash_exports").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val txtFile = CrashReportFileExporter.exportTextFile(context, redactPii)
        val jsonFile = CrashReportFileExporter.exportJsonFile(context)
        val archives = CrashArchiveManager.listArchives(context).take(5)

        val zipFile = File(dir, "UltimateShield_Diagnostics_$stamp.zip")
        ZipOutputStream(zipFile.outputStream().buffered()).use { zos ->
            listOf(txtFile, jsonFile).forEach { f ->
                zos.putNextEntry(ZipEntry(f.name))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
            archives.forEach { arch ->
                zos.putNextEntry(ZipEntry("history/${arch.name}"))
                arch.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        return zipFile
    }
}
