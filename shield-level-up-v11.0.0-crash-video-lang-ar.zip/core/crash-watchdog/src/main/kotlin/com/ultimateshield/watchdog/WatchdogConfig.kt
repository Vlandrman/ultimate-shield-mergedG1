package com.ultimateshield.watchdog

import android.content.Context

data class WatchdogSettings(
    val sweepIntervalMs: Long = 15_000L,
    val anrThresholdMs: Long = 4_500L,
    val fdAlertLimit: Int = 750,
    val minAutoOpenPercent: Int = 85, // Default: Tier [S] (85%+)
    val redactPiiByDefault: Boolean = true,
    val thermalThrottleEnabled: Boolean = true
)

/**
 * Persistent configuration store for tuning Watchdog & Crash Radar thresholds at runtime.
 */
object WatchdogConfig {
    private const val PREFS = "ultimate_shield_watchdog_cfg"

    fun load(context: Context): WatchdogSettings {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return WatchdogSettings(
            sweepIntervalMs = p.getLong("sweep_ms", 15_000L),
            anrThresholdMs = p.getLong("anr_ms", 4_500L),
            fdAlertLimit = p.getInt("fd_limit", 750),
            minAutoOpenPercent = p.getInt("min_open_pct", 85),
            redactPiiByDefault = p.getBoolean("redact_pii", true),
            thermalThrottleEnabled = p.getBoolean("thermal_throttle", true)
        )
    }

    fun save(context: Context, settings: WatchdogSettings) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong("sweep_ms", settings.sweepIntervalMs)
            .putLong("anr_ms", settings.anrThresholdMs)
            .putInt("fd_limit", settings.fdAlertLimit)
            .putInt("min_open_pct", settings.minAutoOpenPercent.coerceIn(10, 100))
            .putBoolean("redact_pii", settings.redactPiiByDefault)
            .putBoolean("thermal_throttle", settings.thermalThrottleEnabled)
            .apply()
    }
}
