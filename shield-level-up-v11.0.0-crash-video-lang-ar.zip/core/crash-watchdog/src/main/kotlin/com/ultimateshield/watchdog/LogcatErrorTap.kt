package com.ultimateshield.watchdog

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Live PID-scoped Logcat Error Tap:
 * Captures native Go/Rust/JNI errors, StrictMode warnings, and SQLiteExceptions
 * emitted for this app PID and routes them directly into CrashRadarRegistry.
 */
class LogcatErrorTap {
    private var job: Job? = null
    @Volatile private var activeProc: Process? = null

    fun start(scope: CoroutineScope) {
        if (job?.isActive == true) return
        val pid = android.os.Process.myPid()
        job = scope.launch(Dispatchers.IO) {
            var proc: Process? = null
            try {
                proc = ProcessBuilder("logcat", "-v", "brief", "--pid=$pid", "*:E").start()
                activeProc = proc
                BufferedReader(InputStreamReader(proc.inputStream)).use { reader ->
                    while (isActive) {
                        val line = reader.readLine() ?: break
                        classifyAndForward(line)
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { proc?.destroy() } catch (_: Exception) {}
                if (activeProc === proc) activeProc = null
            }
        }
    }

    fun stop() {
        try { activeProc?.destroy() } catch (_: Exception) {}
        activeProc = null
        job?.cancel()
        job = null
    }

    private fun classifyAndForward(line: String) {
        val low = line.lowercase()
        val (score, cat, title) = when {
            low.contains("sqliteexception") || low.contains("database is locked") ->
                Triple(76, IssueCategory.ERROR, "خطأ قاعدة بيانات SQLite")
            low.contains("strictmode") || low.contains("leaked") ->
                Triple(68, IssueCategory.PERFORMANCE, "رصد تسريب موارد (StrictMode)")
            low.contains("fatal signal") || low.contains("sigsegv") || low.contains("jni") ->
                Triple(97, IssueCategory.CRASH, "خطأ ذاكرة/JNI حرج في Logcat")
            low.contains("securityexception") || low.contains("sslhandshakeexception") ->
                Triple(82, IssueCategory.VULNERABILITY, "فشل مصادقة أو أمان TLS/Security")
            else -> return
        }

        CrashRadarRegistry.ingest(
            WatchdogRecord(
                category = cat,
                scorePercent = score,
                title = title,
                rootCause = line.take(300),
                autoFixAttempted = false,
                autoFixResult = "تم تسجيل الحدث الفوري من Logcat في السجل الموحّد"
            )
        )
    }
}
