package com.ultimateshield.watchdog

import android.content.Context
import android.os.Build
import android.os.PowerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Thermal & Battery-Drain Watchdog:
 * Monitors Android PowerManager thermal status (API 29+); automatically throttles heavy
 * background scanning / PCAP capture on SEVERE/CRITICAL heat and logs the event to CrashRadarRegistry.
 */
object ThermalAndBatteryGuard {

    private val _isThrottled = MutableStateFlow(false)
    val isThrottled: StateFlow<Boolean> = _isThrottled.asStateFlow()

    fun checkThermalState(context: Context): HealingOutcome {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return HealingOutcome(false)
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            ?: return HealingOutcome(false)
        val status = pm.currentThermalStatus

        if (status < PowerManager.THERMAL_STATUS_SEVERE) {
            if (_isThrottled.value) {
                _isThrottled.value = false
                BreadcrumbTrail.leave("THERMAL", "Device cooled down -> full speed restored")
            }
            return HealingOutcome(false)
        }

        _isThrottled.value = true
        val score = if (status >= PowerManager.THERMAL_STATUS_CRITICAL) 89 else 78 // [S] or [A]
        BreadcrumbTrail.leave("THERMAL", "Thermal status=$status -> background throttled")
        return HealingOutcome(
            issueDetected = true,
            record = WatchdogRecord(
                category = IssueCategory.PERFORMANCE,
                scorePercent = score,
                title = "ارتفاع حرارة الجهاز (Thermal Status=$status)",
                rootCause = "ضغط معالجة مستمر في الخلفية رفع حرارة المعالج لمستوى حرج",
                autoFixAttempted = true,
                autoFixResult = "تم تفعيل الخنق الحراري التلقائي وتأجيل الفحص العميق وPCAP حتى يبرد الجهاز"
            )
        )
    }
}
