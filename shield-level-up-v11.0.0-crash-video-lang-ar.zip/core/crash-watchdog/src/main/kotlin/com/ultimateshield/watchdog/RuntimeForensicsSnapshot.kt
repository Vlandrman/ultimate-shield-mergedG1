package com.ultimateshield.watchdog

import android.os.Debug
import java.io.File

/**
 * Captures live JVM Heap, Native Heap, Open FDs, and Blocked Thread counts at the exact moment of a crash.
 */
object RuntimeForensicsSnapshot {

    fun captureSummary(): String {
        val rt = Runtime.getRuntime()
        val usedJvmMb = (rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L)
        val maxJvmMb = rt.maxMemory() / (1024L * 1024L)
        val nativeMb = Debug.getNativeHeapAllocatedSize() / (1024L * 1024L)
        val openFds = runCatching { File("/proc/self/fd").listFiles()?.size ?: -1 }.getOrDefault(-1)
        val allThreads = Thread.getAllStackTraces().keys
        val blockedCount = allThreads.count { it.state == Thread.State.BLOCKED }

        return "JVM Heap: ${usedJvmMb}/${maxJvmMb} MB | Native Heap: ${nativeMb} MB | Open FDs: $openFds | Threads: ${allThreads.size} (Blocked: $blockedCount)"
    }
}
