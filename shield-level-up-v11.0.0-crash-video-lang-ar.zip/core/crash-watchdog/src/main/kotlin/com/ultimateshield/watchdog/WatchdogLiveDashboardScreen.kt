package com.ultimateshield.watchdog

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * In-App Live Watchdog & Crash Radar Console (accessible from Settings / Diagnostics).
 * Shows all organized records across (E..SSS), live filter chips, Force Sweep, Test Crash,
 * and pinned Copy All + Share Report buttons.
 */
@Composable
fun WatchdogLiveDashboardScreen(
    records: List<WatchdogRecord>,
    onForceSweep: () -> Unit,
    onSimulateCriticalCrash: () -> Unit,
    onCopyAll: (String) -> Unit,
    onShareAll: (String) -> Unit,
    onClearAll: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(records, selectedFilter, searchQuery) {
        when (selectedFilter) {
            "CRITICAL" -> records.filter { it.scorePercent >= 85 } // S, SS, SSS
            "HIGH" -> records.filter { it.scorePercent in 55..84 } // B, A
            "LOW" -> records.filter { it.scorePercent < 55 }       // E, F, D, C
            else -> records
        }.filter {
            searchQuery.isBlank() ||
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.rootCause.contains(searchQuery, ignoreCase = true) ||
                it.tier.code.equals(searchQuery.trim(), ignoreCase = true)
        }
    }

    val fullReport = remember(filtered) { CrashRadarRegistry.buildUnifiedTextReport(filtered) }

    Scaffold(
        containerColor = Color(0xFF0F172A),
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onCopyAll(fullReport) },
                    modifier = Modifier.weight(1f).height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8))
                ) {
                    Text("نسخ كل التفاصيل", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { onShareAll(fullReport) },
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Text("مشاركة السجل", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("مراقب السجلات ورادار الكراش", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("فحص وإصلاح ذاتي مستمر 24/7 · الإجمالي: ${records.size}", color = Color(0xFF94A3B8), fontSize = 13.sp)
                }
                TextButton(onClick = onClearAll) { Text("مسح", color = Color(0xFFFCA5A5)) }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = onForceSweep,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF047857))
                ) { Text("فحص وإصلاح فوري") }
                OutlinedButton(
                    onClick = onSimulateCriticalCrash,
                    modifier = Modifier.weight(1f)
                ) { Text("اختبار كراش [SS]", color = Color(0xFFFCA5A5)) }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("بحث في السجلات أو التصنيف (SSS, OOM, VPN)...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ALL" to "الكل", "CRITICAL" to "S–SSS", "HIGH" to "B–A", "LOW" to "E–C").forEach { (key, label) ->
                    FilterChip(
                        selected = selectedFilter == key,
                        onClick = { selectedFilter = key },
                        label = { Text(label) }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.id }) { rec ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1E293B), shape = MaterialTheme.shapes.small)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = rec.title + if (rec.occurrences > 1) " (×${rec.occurrences})" else "",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            Surface(color = Color(rec.tier.colorHex), shape = MaterialTheme.shapes.extraSmall) {
                                Text(
                                    text = "[${rec.tier.code}] ${rec.scorePercent}%",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text("السبب: ${rec.rootCause}", color = Color(0xFFCBD5E1), fontSize = 13.sp)
                        Text("الإصلاح التلقائي: ${rec.autoFixResult}", color = Color(0xFF6EE7B7), fontSize = 12.5.sp)
                        TextButton(
                            onClick = { onCopyAll(CrashRadarRegistry.buildUnifiedTextReport(listOf(rec))) },
                            contentPadding = PaddingValues(0.dp)
                        ) { Text("نسخ هذا السجل فقط", color = Color(0xFF93C5FD), fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}
