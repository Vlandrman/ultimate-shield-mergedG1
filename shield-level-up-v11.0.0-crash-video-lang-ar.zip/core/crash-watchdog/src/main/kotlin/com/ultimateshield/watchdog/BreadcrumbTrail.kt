package com.ultimateshield.watchdog

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

data class Breadcrumb(
    val timestampMs: Long,
    val source: String,
    val message: String
)

/**
 * Ring-buffered Breadcrumb Trail (last 40 user & engine actions leading up to any crash).
 */
object BreadcrumbTrail {
    private const val MAX_ITEMS = 40
    private val ring = ArrayDeque<Breadcrumb>(MAX_ITEMS)

    @Synchronized
    fun leave(source: String, message: String) {
        if (ring.size >= MAX_ITEMS) ring.removeFirst()
        ring.addLast(Breadcrumb(System.currentTimeMillis(), source, message))
    }

    @Synchronized
    fun formatTrail(): String {
        if (ring.isEmpty()) return "  (No breadcrumbs recorded yet)"
        val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
        return ring.joinToString("\n") { b ->
            "  [${fmt.format(Date(b.timestampMs))}] (${b.source}) ${b.message}"
        }
    }

    @Synchronized
    fun clear() = ring.clear()
}
