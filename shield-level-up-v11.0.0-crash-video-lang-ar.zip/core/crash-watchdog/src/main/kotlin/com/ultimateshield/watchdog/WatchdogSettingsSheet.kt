package com.ultimateshield.watchdog

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Live Watchdog Configuration Sheet for tuning sweep frequency, auto-open severity threshold,
 * PII redaction, and thermal throttling at runtime.
 */
@Composable
fun WatchdogSettingsPanel(
    initial: WatchdogSettings,
    onSave: (WatchdogSettings) -> Unit
) {
    var minOpenPct by remember { mutableIntStateOf(initial.minAutoOpenPercent) }
    var redactPii by remember { mutableStateOf(initial.redactPiiByDefault) }
    var thermalThrottle by remember { mutableStateOf(initial.thermalThrottleEnabled) }

    Column(
        modifier = Modifier.fillMaxWidth().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("إعدادات مراقب السجلات ورادار الكراش", color = Color.White, fontWeight = FontWeight.Bold)

        Text(
            "حد الفتح التلقائي لشاشة الكراش: [${SeverityTier.fromPercent(minOpenPct).code}] $minOpenPct%",
            color = Color(0xFFE2E8F0)
        )
        Slider(
            value = minOpenPct.toFloat(),
            onValueChange = { minOpenPct = it.toInt() },
            valueRange = 70f..97f
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("تعمية الـ IP تلقائياً قبل المشاركة", color = Color(0xFFE2E8F0))
            Switch(checked = redactPii, onCheckedChange = { redactPii = it })
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("الخنق الحراري التلقائي", color = Color(0xFFE2E8F0))
            Switch(checked = thermalThrottle, onCheckedChange = { thermalThrottle = it })
        }

        Button(
            onClick = {
                onSave(
                    initial.copy(
                        minAutoOpenPercent = minOpenPct,
                        redactPiiByDefault = redactPii,
                        thermalThrottleEnabled = thermalThrottle
                    )
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("حفظ الإعدادات")
        }
    }
}
