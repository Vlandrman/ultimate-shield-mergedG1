package com.ultimateshield.watchdog

/**
 * Privacy-preserving redactor for safe external sharing of unified crash reports.
 */
object LogSanitizer {
    private val ipv4Regex = Regex("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b")
    private val emailRegex = Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")

    fun sanitizeForExternalShare(rawReport: String, redactNetworkPii: Boolean = false): String {
        if (!redactNetworkPii) return rawReport
        return rawReport
            .replace(ipv4Regex, "[REDACTED_IP]")
            .replace(emailRegex, "[REDACTED_EMAIL]")
    }
}
