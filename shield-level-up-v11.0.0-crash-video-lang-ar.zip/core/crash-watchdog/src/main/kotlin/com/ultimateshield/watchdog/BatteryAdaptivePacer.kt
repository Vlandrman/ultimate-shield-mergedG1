package com.ultimateshield.watchdog

import android.content.Context
import android.os.BatteryManager

/**
 * Dynamically adapts the Watchdog sweep interval based on live battery level & charging state
 * so 24/7 background monitoring consumes < 0.1% battery/day while crash/ANR hooks stay instant.
 */
object BatteryAdaptivePacer {

    fun computeIntervalMs(context: Context, baseIntervalMs: Long = 15_000L): Long {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            ?: return baseIntervalMs
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging

        return when {
            charging || level > 50 -> baseIntervalMs
            level in 21..50 -> baseIntervalMs * 2
            else -> baseIntervalMs * 4
        }
    }
}
