package com.ultimateshield.watchdog

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

/**
 * Registers a dynamic Android Launcher Long-Press Shortcut ("رادار الكراش والسجلات")
 * so the Watchdog Console is always 1-tap reachable even if the main UI misbehaves.
 */
object WatchdogShortcuts {
    private const val SHORTCUT_ID = "shortcut_open_crash_radar"

    fun registerDynamicShortcut(context: Context) {
        runCatching {
            val intent = Intent(context, WatchdogConsoleActivity::class.java).apply {
                action = Intent.ACTION_VIEW
            }
            val shortcut = ShortcutInfoCompat.Builder(context, SHORTCUT_ID)
                .setShortLabel("رادار الكراش")
                .setLongLabel("فتح مراقب السجلات ورادار الكراش")
                .setIcon(IconCompat.createWithResource(context, android.R.drawable.ic_menu_info_details))
                .setIntent(intent)
                .build()
            ShortcutManagerCompat.pushDynamicShortcut(context, shortcut)
        }
    }
}
