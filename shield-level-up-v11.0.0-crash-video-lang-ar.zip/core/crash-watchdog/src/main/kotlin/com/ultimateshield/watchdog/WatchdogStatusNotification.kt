package com.ultimateshield.watchdog

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/**
 * Background Alert Bridge for Critical (S)/(SS)/(SSS) Crash Radar events when UI is backgrounded.
 */
object WatchdogStatusNotification {
    private const val CHANNEL_ID = "watchdog_critical_radar"
    private const val NOTIF_ID = 9091

    fun notifyCriticalIssue(context: Context, record: WatchdogRecord) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Crash Radar Critical Alerts", NotificationManager.IMPORTANCE_HIGH)
        )

        val openIntent = Intent(context, CrashRadarActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(CrashRadarActivity.EXTRA_TRIGGER_TIER, record.tier.code)
            putExtra(CrashRadarActivity.EXTRA_TRIGGER_SCORE, record.scorePercent)
            putExtra(CrashRadarActivity.EXTRA_TRIGGER_TITLE, record.title)
            putExtra(CrashRadarActivity.EXTRA_TRIGGER_CAUSE, record.rootCause)
        }
        val pi = PendingIntent.getActivity(
            context, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("[${record.tier.code} · ${record.scorePercent}%] ${record.title}")
            .setContentText(record.rootCause)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        runCatching { nm.notify(NOTIF_ID, notif) }
    }
}
