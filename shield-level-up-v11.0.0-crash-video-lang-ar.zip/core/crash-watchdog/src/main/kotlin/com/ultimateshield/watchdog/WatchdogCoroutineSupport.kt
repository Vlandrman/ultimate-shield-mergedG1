package com.ultimateshield.watchdog

import kotlinx.coroutines.CoroutineExceptionHandler
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Drop-in CoroutineExceptionHandler for every ViewModel, Service, and Worker
 * so uncaught exceptions inside SupervisorJob coroutines never fail silently.
 */
object WatchdogCoroutineSupport {

    fun handler(source: String, defaultSeverityPercent: Int = 88): CoroutineExceptionHandler =
        CoroutineExceptionHandler { _, throwable ->
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))
            BreadcrumbTrail.leave(source, "Coroutine crash: ${throwable.javaClass.simpleName}")
            CrashRadarRegistry.ingest(
                WatchdogRecord(
                    category = IssueCategory.CRASH,
                    scorePercent = defaultSeverityPercent,
                    title = "انهيار Coroutine في [$source]: ${throwable.javaClass.simpleName}",
                    rootCause = throwable.message ?: "استثناء غير معالج داخل مهمة خلفية",
                    autoFixAttempted = true,
                    autoFixResult = "تم احتواء الانهيار داخل نطاق Coroutine دون إسقاط بقية الوحدات",
                    stackTrace = sw.toString()
                )
            )
        }
}
