package com.ultimateshield.watchdog

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Ring-Rotated Persistent Crash Archive:
 * Keeps up to 20 historical crash sessions (<= 5 MB total) across app restarts.
 */
object CrashArchiveManager {
    private const val MAX_ARCHIVES = 20
    private const val MAX_TOTAL_BYTES = 5L * 1024L * 1024L

    fun archiveReport(context: Context, unifiedReport: String): File {
        val dir = File(context.filesDir, "crash_archive").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val out = File(dir, "session_$stamp.log")
        out.writeText(unifiedReport, Charsets.UTF_8)
        enforceRetention(dir)
        return out
    }

    fun listArchives(context: Context): List<File> {
        val dir = File(context.filesDir, "crash_archive")
        return dir.listFiles()?.sortedByDescending { it.lastModified() }.orEmpty()
    }

    private fun enforceRetention(dir: File) {
        val files = dir.listFiles()?.sortedByDescending { it.lastModified() }?.toMutableList() ?: return
        while (files.size > MAX_ARCHIVES) {
            files.removeAt(files.lastIndex).delete()
        }
        var total = files.sumOf { it.length() }
        while (total > MAX_TOTAL_BYTES && files.size > 1) {
            val oldest = files.removeAt(files.lastIndex)
            total -= oldest.length()
            oldest.delete()
        }
    }
}
