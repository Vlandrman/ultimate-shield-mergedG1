package com.ultimateshield.watchdog

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Exports full unified crash & watchdog logs as .txt and .json files
 * (avoids Android 1 MB Binder TransactionTooLargeException on massive stack traces).
 */
object CrashReportFileExporter {

    fun exportTextFile(context: Context, redactPii: Boolean = false): File {
        val dir = File(context.cacheDir, "crash_exports").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val out = File(dir, "UltimateShield_CrashRadar_$stamp.txt")
        val raw = CrashRadarRegistry.buildUnifiedTextReport()
        out.writeText(LogSanitizer.sanitizeForExternalShare(raw, redactPii), Charsets.UTF_8)
        return out
    }

    fun exportJsonFile(context: Context): File {
        val dir = File(context.cacheDir, "crash_exports").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val out = File(dir, "UltimateShield_CrashRadar_$stamp.json")
        val arr = JSONArray()
        CrashRadarRegistry.getSortedRecords().forEach { r ->
            arr.put(
                JSONObject().apply {
                    put("id", r.id)
                    put("tier", r.tier.code)
                    put("score_percent", r.scorePercent)
                    put("category", r.category.name)
                    put("occurrences", r.occurrences)
                    put("title", r.title)
                    put("root_cause", r.rootCause)
                    put("auto_fix_result", r.autoFixResult)
                    put("thread", r.threadName)
                    put("timestamp_ms", r.timestampMs)
                }
            )
        }
        out.writeText(JSONObject().put("records", arr).toString(2), Charsets.UTF_8)
        return out
    }
}
