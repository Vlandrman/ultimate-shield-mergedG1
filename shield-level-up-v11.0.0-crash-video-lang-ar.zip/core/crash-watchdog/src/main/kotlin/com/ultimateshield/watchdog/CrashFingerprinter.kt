package com.ultimateshield.watchdog

import java.security.MessageDigest

/**
 * Generates a stable 12-char SHA-256 fingerprint from exception type + top 3 app stack frames
 * so recurring crashes across sessions are grouped deterministically.
 */
object CrashFingerprinter {

    fun fingerprint(title: String, stackTrace: String): String {
        val topFrames = stackTrace.lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("at ") }
            .take(3)
            .joinToString("|")
        val seed = "$title::$topFrames"
        return MessageDigest.getInstance("SHA-256")
            .digest(seed.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
            .take(12)
            .uppercase()
    }
}
