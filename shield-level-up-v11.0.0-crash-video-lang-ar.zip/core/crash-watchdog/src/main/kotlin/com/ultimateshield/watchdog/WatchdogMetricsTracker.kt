package com.ultimateshield.watchdog

/**
 * Zero-Telemetry Local Health KPI Tracker:
 * Computes Auto-Heal Success Rate, Session Uptime, and exact (E..SSS) Tier Histogram.
 */
object WatchdogMetricsTracker {
    private val startedAtMs: Long = System.currentTimeMillis()

    fun buildSummaryLine(records: List<WatchdogRecord>): String {
        val uptimeMin = ((System.currentTimeMillis() - startedAtMs) / 60_000L).coerceAtLeast(0L)
        val total = records.size
        val autoFixed = records.count { it.autoFixAttempted }
        val rate = if (total == 0) 100 else (autoFixed * 100) / total
        val counts = SeverityTier.entries.reversed().mapNotNull { t ->
            val c = records.count { it.tier == t }
            if (c > 0) "${t.code}:$c" else null
        }.joinToString(" | ").ifBlank { "Clean" }

        return "Uptime: ${uptimeMin}m | Auto-Heal Rate: ${rate}% ($autoFixed/$total) | Tiers: [$counts]"
    }
}
