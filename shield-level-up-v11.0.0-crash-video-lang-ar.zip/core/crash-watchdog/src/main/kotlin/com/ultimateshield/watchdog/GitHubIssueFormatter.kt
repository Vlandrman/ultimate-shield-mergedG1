package com.ultimateshield.watchdog

import android.os.Build

/**
 * Formats the unified Crash Radar records into clean GitHub Issue Markdown
 * with collapsible StackTrace and Breadcrumbs blocks for fast bug triage.
 */
object GitHubIssueFormatter {

    fun formatMarkdown(records: List<WatchdogRecord>, redactPii: Boolean = true): String {
        val peak = records.maxByOrNull { it.scorePercent }
        val sb = StringBuilder()
        sb.appendLine("## Ultimate Shield Crash Radar Report")
        sb.appendLine()
        sb.appendLine("- **Peak Tier:** `[${peak?.tier?.code ?: "E"}]` (${peak?.scorePercent ?: 10}%)")
        sb.appendLine("- **Total Issues:** ${records.size}")
        sb.appendLine("- **Device:** ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT})")
        sb.appendLine("- **Runtime:** `${RuntimeForensicsSnapshot.captureSummary()}`")
        sb.appendLine("- **Health KPIs:** `${WatchdogMetricsTracker.buildSummaryLine(records)}`")
        sb.appendLine()
        sb.appendLine("### Recorded Issues")
        records.forEachIndexed { idx, r ->
            val fp = CrashFingerprinter.fingerprint(r.title, r.stackTrace)
            val advice = RootCauseAdvisor.diagnose(r.title, r.rootCause, r.stackTrace)
            sb.appendLine("${idx + 1}. **[${r.tier.code} · ${r.scorePercent}%]** `${r.title}` (FP: `$fp`, ×${r.occurrences})")
            sb.appendLine("   - **Root Cause:** ${r.rootCause}")
            sb.appendLine("   - **Diagnosis:** ${advice.arabicDiagnosis}")
            sb.appendLine("   - **Auto-Fix:** ${r.autoFixResult}")
            if (r.stackTrace.isNotBlank()) {
                sb.appendLine("   <details><summary>StackTrace</summary>")
                sb.appendLine()
                sb.appendLine("   ```text")
                sb.appendLine(r.stackTrace.trim())
                sb.appendLine("   ```")
                sb.appendLine("   </details>")
            }
        }
        sb.appendLine()
        sb.appendLine("<details><summary>Last 40 Breadcrumbs</summary>")
        sb.appendLine()
        sb.appendLine("```text")
        sb.appendLine(BreadcrumbTrail.formatTrail())
        sb.appendLine("```")
        sb.appendLine("</details>")
        return LogSanitizer.sanitizeForExternalShare(sb.toString(), redactPii)
    }
}
