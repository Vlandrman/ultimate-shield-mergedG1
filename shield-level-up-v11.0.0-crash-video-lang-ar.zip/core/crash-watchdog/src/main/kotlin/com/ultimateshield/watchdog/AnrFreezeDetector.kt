package com.ultimateshield.watchdog

import android.os.Handler
import android.os.Looper
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Main-Thread ANR Freeze Detector.
 * Pings the Main Looper every 4.5s; if blocked, captures the exact Main Thread stack trace
 * and pushes a (S) (88%) or (SS) (94%) record immediately to CrashRadarRegistry.
 */
class AnrFreezeDetector(
    private val freezeThresholdMs: Long = 4_500L
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val responded = AtomicBoolean(true)
    @Volatile private var running = false
    private var worker: Thread? = null

    fun start() {
        if (running) return
        running = true
        worker = Thread({
            while (running) {
                responded.set(false)
                val sentAt = System.currentTimeMillis()
                mainHandler.post { responded.set(true) }
                try {
                    Thread.sleep(freezeThresholdMs)
                } catch (_: InterruptedException) {
                    break
                }
                if (!responded.get() && running) {
                    val elapsed = System.currentTimeMillis() - sentAt
                    val mainThread = Looper.getMainLooper().thread
                    val trace = mainThread.stackTrace.joinToString("\n") { "    at $it" }
                    val score = if (elapsed >= 8_000L) 94 else 88 // [SS] or [S]
                    CrashRadarRegistry.ingest(
                        WatchdogRecord(
                            category = IssueCategory.PERFORMANCE,
                            scorePercent = score,
                            title = "تجمّد الواجهة الرئيسية ANR (${elapsed}ms)",
                            rootCause = "عملية ثقيلة أو قفل متزامن عطّل الخيط الرئيسي (Main Thread)",
                            autoFixAttempted = true,
                            autoFixResult = "تم التقاط مكدس الخيط الرئيسي وإرساله فوراً لرادار الكراش",
                            threadName = mainThread.name,
                            stackTrace = trace
                        )
                    )
                }
            }
        }, "UltimateShield-ANR-Watchdog").apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        running = false
        worker?.interrupt()
        worker = null
    }
}
