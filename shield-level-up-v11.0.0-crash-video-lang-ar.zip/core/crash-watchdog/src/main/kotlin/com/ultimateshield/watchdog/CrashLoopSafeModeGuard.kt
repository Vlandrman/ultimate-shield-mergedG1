package com.ultimateshield.watchdog

import android.content.Context

/**
 * Boot-Loop / Crash-Loop Protection:
 * If >= 3 fatal crashes happen within 60 seconds, activates Safe Mode on next launch
 * so heavy ML/PCAP modules pause automatically and CrashRadarActivity stays accessible.
 */
object CrashLoopSafeModeGuard {
    private const val PREFS = "ultimate_shield_safe_mode"
    private const val KEY_TIMESTAMPS = "crash_ts_csv"
    private const val KEY_SAFE_MODE = "safe_mode_active"
    private const val WINDOW_MS = 60_000L
    private const val LOOP_THRESHOLD = 3

    fun recordFatalCrash(context: Context, nowMs: Long = System.currentTimeMillis()): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_TIMESTAMPS, "")
            .orEmpty()
            .split(",")
            .mapNotNull { it.toLongOrNull() }
            .filter { nowMs - it <= WINDOW_MS }
            .toMutableList()
        existing.add(nowMs)

        val enterSafeMode = existing.size >= LOOP_THRESHOLD
        // Use commit() synchronously because the process is about to terminate
        prefs.edit()
            .putString(KEY_TIMESTAMPS, existing.joinToString(","))
            .putBoolean(KEY_SAFE_MODE, enterSafeMode)
            .commit()
        return enterSafeMode
    }

    fun isSafeModeActive(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SAFE_MODE, false)

    fun exitSafeMode(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_SAFE_MODE, false)
            .remove(KEY_TIMESTAMPS)
            .apply()
    }
}
