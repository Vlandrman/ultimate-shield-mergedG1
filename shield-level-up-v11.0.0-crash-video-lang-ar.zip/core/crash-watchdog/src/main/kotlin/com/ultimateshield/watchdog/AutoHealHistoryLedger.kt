package com.ultimateshield.watchdog

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

data class AutoHealEntry(
    val timestampMs: Long = System.currentTimeMillis(),
    val targetSubsystem: String,
    val actionTaken: String,
    val succeeded: Boolean
)

/**
 * Dedicated ledger of every background self-healing action executed by the Watchdog,
 * appended cleanly to the Unified Crash Radar Report.
 */
object AutoHealHistoryLedger {
    private const val MAX_ENTRIES = 50
    private val entries = CopyOnWriteArrayList<AutoHealEntry>()

    fun record(subsystem: String, actionTaken: String, succeeded: Boolean) {
        entries.add(AutoHealEntry(targetSubsystem = subsystem, actionTaken = actionTaken, succeeded = succeeded))
        while (entries.size > MAX_ENTRIES) {
            entries.removeAt(0)
        }
    }

    fun formatLedger(): String {
        if (entries.isEmpty()) return "  (No background auto-heal actions triggered yet)"
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        return entries.joinToString("\n") { e ->
            val status = if (e.succeeded) "OK" else "FAILED"
            "  [${fmt.format(Date(e.timestampMs))}] [$status] (${e.targetSubsystem}) ${e.actionTaken}"
        }
    }

    fun clear() = entries.clear()
}
