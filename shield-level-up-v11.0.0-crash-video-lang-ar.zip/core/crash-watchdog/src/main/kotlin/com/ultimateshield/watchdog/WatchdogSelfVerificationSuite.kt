package com.ultimateshield.watchdog

import android.content.Context

data class SelfCheckSummary(
    val passed: Int,
    val total: Int,
    val details: String
)

/**
 * Safe one-tap runtime verification suite confirming all 9 (E..SSS) tiers,
 * AES-256-GCM EncryptedCrashStore, LogSanitizer PII redaction, and RootCauseAdvisor work on-device.
 */
object WatchdogSelfVerificationSuite {

    fun runAll(context: Context): SelfCheckSummary {
        val results = mutableListOf<Pair<String, Boolean>>()

        // 1. All 9 severity tiers exact boundaries
        val tiersOk = SeverityTier.fromPercent(10) == SeverityTier.E &&
            SeverityTier.fromPercent(25) == SeverityTier.F &&
            SeverityTier.fromPercent(35) == SeverityTier.D &&
            SeverityTier.fromPercent(50) == SeverityTier.C &&
            SeverityTier.fromPercent(60) == SeverityTier.B &&
            SeverityTier.fromPercent(80) == SeverityTier.A &&
            SeverityTier.fromPercent(88) == SeverityTier.S &&
            SeverityTier.fromPercent(94) == SeverityTier.SS &&
            SeverityTier.fromPercent(99) == SeverityTier.SSS
        results.add("9-Tier Scale [E..SSS]" to tiersOk)

        // 2. PII Redaction
        val redacted = LogSanitizer.sanitizeForExternalShare("IP 192.168.0.10", true)
        results.add("PII Redaction" to redacted.contains("[REDACTED_IP]"))

        // 3. Arabic Root-Cause Advisor
        val adv = RootCauseAdvisor.diagnose("OOM", "OutOfMemoryError", "")
        results.add("Arabic RootCauseAdvisor" to adv.arabicDiagnosis.contains("الذاكرة"))

        // 4. Encrypted Crash Store round-trip
        val encOk = runCatching {
            EncryptedCrashStore.writeEncrypted(context, "probe-ok")
            EncryptedCrashStore.readEncrypted(context) == "probe-ok"
        }.getOrDefault(false)
        results.add("AES-256-GCM CrashStore" to encOk)

        val passed = results.count { it.second }
        val details = results.joinToString(" | ") { (k, ok) -> "$k=${if (ok) "PASS" else "FAIL"}" }
        BreadcrumbTrail.leave("VERIFY", "Self-check $passed/${results.size}: $details")
        return SelfCheckSummary(passed, results.size, details)
    }
}
