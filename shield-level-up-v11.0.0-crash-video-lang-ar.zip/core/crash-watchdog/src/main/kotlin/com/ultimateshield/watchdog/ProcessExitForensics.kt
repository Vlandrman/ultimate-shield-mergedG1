package com.ultimateshield.watchdog

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build

/**
 * Android 11+ (API 30+) Post-Mortem Forensics:
 * Recovers silent native SIGSEGV crashes, OS ANR kills, and LMK (OOM) terminations
 * from ActivityManager.getHistoricalProcessExitReasons() on the very next app launch.
 */
object ProcessExitForensics {

    private const val PREF_NAME = "ultimate_shield_exit_forensics"
    private const val KEY_LAST_TS = "last_seen_exit_ts"

    fun inspectPreviousDeaths(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val lastSeen = prefs.getLong(KEY_LAST_TS, 0L)

        val exits = runCatching {
            am.getHistoricalProcessExitReasons(context.packageName, 0, 5)
        }.getOrDefault(emptyList())

        var newestTs = lastSeen
        for (info in exits) {
            if (info.timestamp <= lastSeen) continue
            if (info.timestamp > newestTs) newestTs = info.timestamp

            val (score, cat, label) = when (info.reason) {
                ApplicationExitInfo.REASON_CRASH_NATIVE -> Triple(99, IssueCategory.CRASH, "انهيار أصلي قاتل (Native SIGSEGV/JNI)")
                ApplicationExitInfo.REASON_CRASH -> Triple(95, IssueCategory.CRASH, "انهيار تطبيق سابق (Java/Kotlin Crash)")
                ApplicationExitInfo.REASON_ANR -> Triple(93, IssueCategory.PERFORMANCE, "إنهاء بسبب تجمّد النظام (OS ANR)")
                ApplicationExitInfo.REASON_LOW_MEMORY -> Triple(86, IssueCategory.PERFORMANCE, "قتل العملية بسبب نقص الذاكرة (LMK/OOM)")
                else -> continue
            }

            val traceSnippet = runCatching {
                info.traceInputStream?.bufferedReader()?.use { it.readText().take(4000) }.orEmpty()
            }.getOrDefault("")

            CrashRadarRegistry.ingest(
                WatchdogRecord(
                    timestampMs = info.timestamp,
                    category = cat,
                    scorePercent = score,
                    title = label,
                    rootCause = info.description ?: "Exit status=${info.status}, RSS=${info.rss / 1024} MB",
                    autoFixAttempted = true,
                    autoFixResult = "تم استرجاع تقرير الانهيار الصامت بعد إعادة التشغيل وتوثيقه في رادار الكراش",
                    threadName = info.processName,
                    stackTrace = traceSnippet
                )
            )
        }
        if (newestTs > lastSeen) {
            prefs.edit().putLong(KEY_LAST_TS, newestTs).apply()
        }
    }
}
