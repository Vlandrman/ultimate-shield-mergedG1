package com.ultimateshield.watchdog

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue

/**
 * Direct launcher Activity for opening the live Watchdog & Crash Radar Console
 * from Settings or Diagnostics with a single startActivity() call.
 */
class WatchdogConsoleActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val records by CrashRadarRegistry.recordsFlow.collectAsState()
                WatchdogLiveDashboardScreen(
                    records = records,
                    onForceSweep = {
                        AutoHealerEngine.checkFileDescriptors().record?.let { CrashRadarRegistry.ingest(it) }
                        AutoHealerEngine.checkStorageAndPurgeCache(this).record?.let { CrashRadarRegistry.ingest(it) }
                        Toast.makeText(this, "تم تنفيذ فحص وإصلاح فوري", Toast.LENGTH_SHORT).show()
                    },
                    onSimulateCriticalCrash = {
                        CrashRadarRegistry.ingest(
                            WatchdogRecord(
                                category = IssueCategory.CRASH,
                                scorePercent = 95,
                                title = "اختبار كراش قوي تجريبي [SS]",
                                rootCause = "محاكاة انهيار للتحقق من شاشة رادار الكراش والنسخ والمشاركة",
                                autoFixAttempted = true,
                                autoFixResult = "تم التقاط الاختبار بنجاح وتنظيم السجل الموحّد"
                            ),
                            forceOpenScreen = true
                        )
                    },
                    onCopyAll = { text ->
                        val cm = getSystemService(ClipboardManager::class.java)
                        cm?.setPrimaryClip(ClipData.newPlainText("UltimateShield_WatchdogLog", text))
                        Toast.makeText(this, "تم نسخ كل التفاصيل", Toast.LENGTH_SHORT).show()
                    },
                    onShareAll = { text ->
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "Ultimate Shield — Unified Watchdog & Crash Log")
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        startActivity(Intent.createChooser(share, "مشاركة السجل الموحّد"))
                    },
                    onClearAll = { CrashRadarRegistry.clearAll() }
                )
            }
        }
    }
}
