package com.ultimateshield.watchdog

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/**
 * Verifies that TRANSPORT_VPN is actually present on the active Android network
 * whenever the user expects Shield VPN protection to be active.
 */
object NetworkIntegrityWatchdog {

    fun verifyVpnTransportActive(context: Context, shieldExpectedActive: Boolean): HealingOutcome {
        if (!shieldExpectedActive) return HealingOutcome(false)
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return HealingOutcome(false)

        val activeNet = cm.activeNetwork
        val caps = activeNet?.let { cm.getNetworkCapabilities(it) }
        val hasVpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        if (hasVpn) return HealingOutcome(false)

        BreadcrumbTrail.leave("VPN", "TRANSPORT_VPN missing while Shield expected ON")
        return HealingOutcome(
            issueDetected = true,
            record = WatchdogRecord(
                category = IssueCategory.VPN_NETWORK,
                scorePercent = 87, // [S]
                title = "اختفاء صامت لنقل TRANSPORT_VPN أثناء تفعيل الحماية",
                rootCause = "أغلق النظام أو تطبيق VPN منافس النفق المحلي دون إشعار الواجهة",
                autoFixAttempted = true,
                autoFixResult = "تم تسجيل فقدان النفق وإرسال إشارة إعادة التفعيل الفوري"
            )
        )
    }
}
