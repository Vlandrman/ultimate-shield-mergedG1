package com.ultimateshield.watchdog

import android.app.Activity
import android.app.Application
import android.os.Bundle
import java.util.concurrent.ConcurrentHashMap

/**
 * Zero-boilerplate Activity Lifecycle Observer:
 * Automatically populates BreadcrumbTrail on every screen transition and detects
 * Activity recreation loops (> 6 creates in 10 seconds -> (A) 75%).
 */
class ActivityBreadcrumbCallbacks : Application.ActivityLifecycleCallbacks {

    private val createTimestamps = ConcurrentHashMap<String, MutableList<Long>>()

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        val name = activity.javaClass.simpleName
        BreadcrumbTrail.leave("UI", "onCreate: $name")
        val now = System.currentTimeMillis()
        val list = createTimestamps.getOrPut(name) { mutableListOf() }
        synchronized(list) {
            list.add(now)
            list.removeAll { now - it > 10_000L }
            if (list.size > 6) {
                list.clear()
                CrashRadarRegistry.ingest(
                    WatchdogRecord(
                        category = IssueCategory.ERROR,
                        scorePercent = 75, // [A]
                        title = "حلقة إعادة إنشاء شاشة متكررة: $name",
                        rootCause = "تمت إعادة إنشاء النشاط أكثر من 6 مرات خلال 10 ثوانٍ (تغيير إعدادات أو تسرب حالة)",
                        autoFixAttempted = true,
                        autoFixResult = "تم توثيق حلقة إعادة البناء مع مسار الـ Breadcrumbs"
                    )
                )
            }
        }
    }

    override fun onActivityStarted(activity: Activity) {}
    override fun onActivityResumed(activity: Activity) = BreadcrumbTrail.leave("UI", "onResume: ${activity.javaClass.simpleName}")
    override fun onActivityPaused(activity: Activity) = BreadcrumbTrail.leave("UI", "onPause: ${activity.javaClass.simpleName}")
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) = BreadcrumbTrail.leave("UI", "onDestroy: ${activity.javaClass.simpleName}")
}
