# `:core:crash-watchdog` — Continuous Self-Healing Watchdog & Crash Radar (v2.3)

## 9-Tier Severity Scale (`SeverityTier.kt`)
| Tier | Percentage | Auto-Opens Crash Radar Screen? |
|---|---|---|
| `[E]` | `10% - 19%` | No |
| `[F]` | `20% - 29%` | No |
| `[D]` | `30% - 39%` | No |
| `[C]` | `40% - 54%` | No |
| `[B]` | `55% - 69%` | No |
| `[A]` | `70% - 84%` | No |
| `[S]` | `85% - 91%` | **Yes (Immediate)** |
| `[SS]` | `92% - 96%` | **Yes (Immediate)** |
| `[SSS]` | `97% - 100%` | **Yes (Immediate)** |

## One-Line Usage Across Any Module
```kotlin
WatchdogHub.start(application)
WatchdogHub.breadcrumb("VPN", "Tunnel established")
WatchdogHub.report(IssueCategory.VULNERABILITY, 95, "Rogue CA", "Detected user cert")
WatchdogHub.openConsole(context)
```
