package com.ultimateshield.shizuku

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class ShannonEntropyDetectorTest {

    @Test
    fun normalPlainTextDoesNotTriggerRansomwareAlert() {
        val detector = ShannonEntropyDetector()
        val text = "Hello world normal log entry ".repeat(100).toByteArray()
        repeat(20) { i ->
            assertFalse(detector.recordFileWrite(text, nowMs = 1000L + i * 50L))
        }
    }

    @Test
    fun rapidHighEntropyWritesTriggerGuardianKillSwitch() {
        val detector = ShannonEntropyDetector(burstLimit = 15)
        val rng = Random(42)
        var triggered = false
        repeat(16) { i ->
            val encryptedChunk = rng.nextBytes(4096)
            if (detector.recordFileWrite(encryptedChunk, nowMs = 2000L + i * 100L)) {
                triggered = true
            }
        }
        assertTrue(triggered)
    }
}
