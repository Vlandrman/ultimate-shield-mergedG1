package com.ultimateshield.shizuku

import java.util.ArrayDeque
import kotlin.math.ln

/**
 * Behavioral Anti-Ransomware Detector (Guardian Mode).
 * Tracks high-entropy file write bursts (H > 7.5 bits/byte) inside a 5-second sliding window.
 */
class ShannonEntropyDetector(
    private val entropyThreshold: Double = 7.5,
    private val windowMs: Long = 5_000L,
    private val burstLimit: Int = 15
) {
    private val highEntropyTimestamps = ArrayDeque<Long>()

    fun shannonEntropy(sample: ByteArray): Double {
        if (sample.isEmpty()) return 0.0
        val freq = IntArray(256)
        for (b in sample) freq[b.toInt() and 0xFF]++
        val len = sample.size.toDouble()
        var h = 0.0
        for (count in freq) {
            if (count == 0) continue
            val p = count / len
            h -= p * (ln(p) / ln(2.0))
        }
        return h
    }

    /**
     * Returns true when a ransomware burst threshold is crossed,
     * signaling Shizuku IPC to execute `am force-stop <pkg>` & `pm suspend <pkg>`.
     */
    @Synchronized
    fun recordFileWrite(sample: ByteArray, nowMs: Long = System.currentTimeMillis()): Boolean {
        val h = shannonEntropy(sample)
        if (h < entropyThreshold) return false

        highEntropyTimestamps.addLast(nowMs)
        while (highEntropyTimestamps.isNotEmpty() && nowMs - highEntropyTimestamps.first() > windowMs) {
            highEntropyTimestamps.removeFirst()
        }
        return highEntropyTimestamps.size >= burstLimit
    }
}
