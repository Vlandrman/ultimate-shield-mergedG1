package com.deepfakeshield.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.deepfakeshield.service.EmbeddedTorManager

class TorToggleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val enabled = intent.getBooleanExtra("enabled", false)
        val rawCountry = intent.getStringExtra("exit_country")?.trim()?.lowercase() ?: "auto"
        val exitCountry = if (rawCountry == "auto" || Regex("^[a-z]{2}$").matches(rawCountry)) rawCountry else "auto"
        Log.i("TorToggle", "Tor toggle: enabled=$enabled, exit=$exitCountry")
        try {
            if (enabled) {
                EmbeddedTorManager.start(context.applicationContext, exitCountry)
            } else {
                EmbeddedTorManager.stop(context.applicationContext)
            }
        } catch (e: Exception) {
            Log.e("TorToggle", "Tor toggle failed: ${e.message}")
        }
    }
}
