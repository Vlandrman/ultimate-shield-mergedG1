#!/usr/bin/env python3
"""
Automated Threat-Intel Compiler & Ed25519 Manifest Generator (V3/V7).
Compiles raw signature lists into compressed binary blobs and emits a versioned manifest.json.
"""
import hashlib, json, os, sys, time, zlib

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def compile_db(raw_sigs_path: str, out_dir: str, version: int):
    os.makedirs(out_dir, exist_ok=True)
    with open(raw_sigs_path, "rb") as f:
        raw = f.read()
    compressed = zlib.compress(raw, level=9)
    bin_path = os.path.join(out_dir, "sigs.sigbin.z")
    with open(bin_path, "wb") as f:
        f.write(compressed)

    manifest = {
        "channel": "stable",
        "version": version,
        "generated_utc": int(time.time()),
        "rollback_safe": True,
        "artifacts": {
            "sigs_full": {
                "filename": "sigs.sigbin.z",
                "sha256": sha256_file(bin_path),
                "size_bytes": os.path.getsize(bin_path)
            }
        }
    }
    manifest_path = os.path.join(out_dir, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    print(f"Built signed-ready bundle v{version} -> {manifest_path}")
    print("Next: sign sigs.sigbin.z & manifest.json offline with Ed25519 private key.")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 build_signed_threat_db.py <raw_sigs.txt> <out_dir>")
        sys.exit(1)
    compile_db(sys.argv[1], sys.argv[2], int(time.strftime("%Y%m%d01")))
