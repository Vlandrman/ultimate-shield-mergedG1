package com.ultimateshield.watchdog

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Debug
import java.io.File

/**
 * Self-Protection Watchdog:
 * Detects unexpected debugger attachment in release builds or Frida/hooking artifacts in /proc/self/maps,
 * escalating immediately to [SSS] (98%) in CrashRadarRegistry.
 */
object AppIntegritySelfCheck {

    fun inspectSelfIntegrity(context: Context): HealingOutcome {
        val isDebuggable = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        if (!isDebuggable && Debug.isDebuggerConnected()) {
            return HealingOutcome(
                issueDetected = true,
                record = WatchdogRecord(
                    category = IssueCategory.VULNERABILITY,
                    scorePercent = 98, // [SSS]
                    title = "اكتشاف محاولة تصحيح (Debugger) في نسخة الإنتاج",
                    rootCause = "اتصال مصحح خارجي بعملية تطبيق الحماية في إصدار غير مخصص للتطوير",
                    autoFixAttempted = true,
                    autoFixResult = "تم توثيق محاولة العبث وإغلاق عمليات التصدير الحساسة مؤقتاً"
                )
            )
        }

        val fridaDetected = runCatching {
            File("/proc/self/maps").bufferedReader().use { reader ->
                reader.lineSequence().any { line ->
                    val low = line.lowercase()
                    "frida" in low || "xposed" in low
                }
            }
        }.getOrDefault(false)

        if (fridaDetected) {
            return HealingOutcome(
                issueDetected = true,
                record = WatchdogRecord(
                    category = IssueCategory.VULNERABILITY,
                    scorePercent = 98, // [SSS]
                    title = "رصد حقن برمجي في الذاكرة (Frida/Hooking)",
                    rootCause = "ظهور مكتبات حقن ديناميكية داخل /proc/self/maps لعملية التطبيق",
                    autoFixAttempted = true,
                    autoFixResult = "تم رفع إنذار [SSS] وتوثيق البيئة في رادار الكراش"
                )
            )
        }
        return HealingOutcome(false)
    }
}
