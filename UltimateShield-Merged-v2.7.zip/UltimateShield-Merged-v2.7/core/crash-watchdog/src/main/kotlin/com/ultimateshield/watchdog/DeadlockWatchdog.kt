package com.ultimateshield.watchdog

import java.util.concurrent.ConcurrentHashMap

/**
 * Persistent Blocked-Thread & Deadlock Detector:
 * Tracks threads remaining in Thread.State.BLOCKED across >= 2 consecutive watchdog sweeps.
 * Captures their full stack traces and reports a [SS] (94%) deadlock alert to CrashRadarRegistry.
 */
object DeadlockWatchdog {

    private val blockedStreak = ConcurrentHashMap<Long, Int>()

    fun inspectThreads(): HealingOutcome {
        val traces = Thread.getAllStackTraces()
        val currentlyBlocked = mutableSetOf<Long>()
        val deadlocked = mutableListOf<Pair<Thread, Array<StackTraceElement>>>()

        for ((thread, stack) in traces) {
            if (thread.state == Thread.State.BLOCKED) {
                currentlyBlocked.add(thread.id)
                val streak = (blockedStreak[thread.id] ?: 0) + 1
                blockedStreak[thread.id] = streak
                if (streak >= 2) {
                    deadlocked.add(thread to stack)
                }
            }
        }
        blockedStreak.keys.retainAll(currentlyBlocked)

        if (deadlocked.isEmpty()) return HealingOutcome(false)

        val names = deadlocked.joinToString(", ") { it.first.name }
        val combinedStack = deadlocked.joinToString("\n\n") { (t, st) ->
            "Thread[${t.name}] BLOCKED:\n" + st.take(15).joinToString("\n") { "    at $it" }
        }
        return HealingOutcome(
            issueDetected = true,
            record = WatchdogRecord(
                category = IssueCategory.PERFORMANCE,
                scorePercent = 94, // [SS]
                title = "رصد جمود متبادل في الخيوط (Deadlock): $names",
                rootCause = "بقاء ${deadlocked.size} خيط/خيوط في حالة BLOCKED لدورتين متتاليتين",
                autoFixAttempted = true,
                autoFixResult = "تم التقاط مكدس جميع الخيوط العالقة وإرساله فوراً لرادار الكراش",
                stackTrace = combinedStack
            )
        )
    }
}
