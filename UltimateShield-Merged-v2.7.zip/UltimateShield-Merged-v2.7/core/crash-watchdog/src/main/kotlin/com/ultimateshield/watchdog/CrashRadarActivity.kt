package com.ultimateshield.watchdog

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

/**
 * Isolated Crash Radar Screen (runs in :crash_radar process so it ALWAYS opens even on fatal OOM/Native crash).
 * Displays the unified sorted report with severity tier [E..SSS] + Copy All & Share buttons pinned at the bottom.
 */
class CrashRadarActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val reportText = intent.getStringExtra(EXTRA_FULL_REPORT)
            ?: File(filesDir, "unified_crash_radar.log").takeIf { it.exists() }?.readText()
            ?: CrashRadarRegistry.buildUnifiedTextReport()

        val tierCode = intent.getStringExtra(EXTRA_TRIGGER_TIER) ?: "S"
        val score = intent.getIntExtra(EXTRA_TRIGGER_SCORE, 90)
        val title = intent.getStringExtra(EXTRA_TRIGGER_TITLE) ?: "تقرير رصد الكراش والسجلات الموحد"
        val cause = intent.getStringExtra(EXTRA_TRIGGER_CAUSE) ?: ""
        val tier = SeverityTier.fromPercent(score)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CrashRadarScreen(
                    tier = tier,
                    tierCode = tierCode,
                    scorePercent = score,
                    headline = title,
                    rootCause = cause,
                    unifiedReport = reportText,
                    safeModeActive = CrashLoopSafeModeGuard.isSafeModeActive(this),
                    onExitSafeMode = { CrashLoopSafeModeGuard.exitSafeMode(this); Toast.makeText(this, "تم الخروج من الوضع الآمن", Toast.LENGTH_SHORT).show() },
                    onExportFiles = { redact ->
                        val fTxt = CrashReportFileExporter.exportTextFile(this, redact)
                        val fJson = CrashReportFileExporter.exportJsonFile(this)
                        Toast.makeText(this, "تم الحفظ: ${fTxt.name} & ${fJson.name}", Toast.LENGTH_LONG).show()
                    },
                    onCopyAll = { redact -> copyReportToClipboard(LogSanitizer.sanitizeForExternalShare(reportText, redact)) },
                    onShareAll = { redact -> shareReport(LogSanitizer.sanitizeForExternalShare(reportText, redact), tierCode, score) }
                )
            }
        }
    }

    private fun copyReportToClipboard(text: String) {
        val cm = getSystemService(ClipboardManager::class.java)
        cm?.setPrimaryClip(ClipData.newPlainText("UltimateShield_CrashReport", text))
        Toast.makeText(this, "تم نسخ كامل تفاصيل التقرير بنجاح", Toast.LENGTH_SHORT).show()
    }

    private fun shareReport(text: String, tierCode: String, score: Int) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Ultimate Shield Crash Radar [$tierCode - $score%]")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, "مشاركة سجل الكراش الموحّد"))
    }

    companion object {
        const val EXTRA_FULL_REPORT = "extra_full_report"
        const val EXTRA_TRIGGER_TIER = "extra_trigger_tier"
        const val EXTRA_TRIGGER_SCORE = "extra_trigger_score"
        const val EXTRA_TRIGGER_TITLE = "extra_trigger_title"
        const val EXTRA_TRIGGER_CAUSE = "extra_trigger_cause"
    }
}

@Composable
fun CrashRadarScreen(
    tier: SeverityTier,
    tierCode: String,
    scorePercent: Int,
    headline: String,
    rootCause: String,
    unifiedReport: String,
    safeModeActive: Boolean,
    onExitSafeMode: () -> Unit,
    onExportFiles: (Boolean) -> Unit,
    onCopyAll: (Boolean) -> Unit,
    onShareAll: (Boolean) -> Unit
) {
    var redactPii by remember { mutableStateOf(false) }
    Scaffold(
        containerColor = Color(0xFF0F172A),
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { onCopyAll(redactPii) },
                    modifier = Modifier.weight(1f).height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8))
                ) {
                    Text("نسخ كل التفاصيل", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { onShareAll(redactPii) },
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Text("مشاركة السجل", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "رادار الكراش والسجلات الموحد",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Surface(color = Color(tier.colorHex), shape = MaterialTheme.shapes.small) {
                    Text(
                        text = "[ $tierCode ]  $scorePercent%",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Text(text = headline, color = Color(0xFFFCA5A5), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            if (rootCause.isNotBlank()) {
                Text(text = "السبب الجذري: $rootCause", color = Color(0xFFE2E8F0), fontSize = 14.sp)
            }

            if (safeModeActive) {
                Button(
                    onClick = onExitSafeMode,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB45309)),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("الوضع الآمن نشط (حماية من حلقة الانهيار) — اضغط للخروج") }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = redactPii, onCheckedChange = { redactPii = it })
                    Text("تعمية الـ IP قبل النسخ/المشاركة", color = Color(0xFFE2E8F0), fontSize = 13.sp)
                }
                TextButton(onClick = { onExportFiles(redactPii) }) {
                    Text("حفظ .txt/.json", color = Color(0xFF93C5FD))
                }
            }
            HorizontalDivider(color = Color(0xFF334155))

            Text(
                text = unifiedReport,
                color = Color(0xFFCBD5E1),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.5.sp,
                lineHeight = 18.sp
            )
        }
    }
}
