package com.ultimateshield.watchdog

/**
 * Exact 9-Tier Problem & Crash Severity Scale (10% - 100%).
 * [E]   10% - 19%
 * [F]   20% - 29%
 * [D]   30% - 39%
 * [C]   40% - 54%
 * [B]   55% - 69%
 * [A]   70% - 84%
 * [S]   85% - 91%  (Critical -> Auto-opens Crash Radar screen)
 * [SS]  92% - 96%  (Severe Crash -> Auto-opens Crash Radar screen)
 * [SSS] 97% - 100% (Catastrophic Crash/Vuln -> Auto-opens Crash Radar screen)
 */
enum class SeverityTier(
    val code: String,
    val minPercent: Int,
    val maxPercent: Int,
    val arabicLabel: String,
    val colorHex: Long,
    val triggersCrashScreen: Boolean
) {
    E("E", 10, 19, "طفيف جداً", 0xFF64748B, false),
    F("F", 20, 29, "منخفض", 0xFF475569, false),
    D("D", 30, 39, "ملحوظ", 0xFF0369A1, false),
    C("C", 40, 54, "متوسط", 0xFF0F766E, false),
    B("B", 55, 69, "فوق المتوسط", 0xFFB45309, false),
    A("A", 70, 84, "مرتفع", 0xFFC2410C, false),
    S("S", 85, 91, "خطير", 0xFFDC2626, true),
    SS("SS", 92, 96, "خطير جداً / كراش قوي", 0xFFB91C1C, true),
    SSS("SSS", 97, 100, "كارثي / ثغرة أو كراش قاتل", 0xFF7F1D1D, true);

    companion object {
        fun fromPercent(rawPercent: Int): SeverityTier {
            val p = rawPercent.coerceIn(10, 100)
            return entries.first { p in it.minPercent..it.maxPercent }
        }
    }
}
